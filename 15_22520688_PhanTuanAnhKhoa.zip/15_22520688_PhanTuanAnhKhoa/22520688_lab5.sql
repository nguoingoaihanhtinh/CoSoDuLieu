﻿------------------------------ QUANLYBANHANG ------------------------------------------
/*


DELETE FROM KHACHHANG
DELETE FROM NHANVIEN
DELETE FROM SANPHAM
DELETE FROM HOADON
DELETE FROM CTHD

*/
GO

-- I. Ngôn ngữ định nghĩa dữ liệu (Data Definition Language):
-- 1.	Tạo các quan hệ và khai báo các khóa chính, khóa ngoại của quan hệ.
USE master
IF EXISTS (SELECT * FROM SYS.DATABASES WHERE NAME = 'QUANLYBANHANG')
BEGIN
	ALTER DATABASE QUANLYBANHANG SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE QUANLYBANHANG;
END
GO

CREATE DATABASE QUANLYBANHANG
GO

USE QUANLYBANHANG
GO

-------------------------------- KHACHHANG --------------------------------------------
CREATE TABLE KHACHHANG
(
	MAKH CHAR(4) PRIMARY KEY, 
	HOTEN VARCHAR(40) NOT NULL,
	DCHI VARCHAR(50) NOT NULL,
	SODT VARCHAR(20) NOT NULL,
	NGSINH SMALLDATETIME,
	NGDK SMALLDATETIME,
	DOANHSO MONEY NOT NULL
)
GO

--------------------------------- NHANVIEN --------------------------------------------
CREATE TABLE NHANVIEN
(
	MANV CHAR(4) PRIMARY KEY,
	HOTEN VARCHAR(40) NOT NULL,
	SODT VARCHAR(20) NOT NULL,
	NGVL SMALLDATETIME
)
GO

--------------------------------- SANPHAM ---------------------------------------------
CREATE TABLE SANPHAM
(
	MASP CHAR(4) PRIMARY KEY,
	TENSP VARCHAR(40) NOT NULL,
	DVT VARCHAR(20),
	NUOCSX VARCHAR(40),
	GIA MONEY NOT NULL
)
GO

---------------------------------- HOADON ---------------------------------------------
CREATE TABLE HOADON
(
	SOHD INT PRIMARY KEY,
	NGHD SMALLDATETIME,
	MAKH CHAR(4) FOREIGN KEY REFERENCES KHACHHANG(MAKH),
	MANV CHAR(4) FOREIGN KEY REFERENCES NHANVIEN(MANV),
	TRIGIA MONEY
)
GO

----------------------------------- CTHD ----------------------------------------------
CREATE TABLE CTHD
(
	SOHD INT FOREIGN KEY REFERENCES HOADON(SOHD),
	MASP CHAR(4) FOREIGN KEY REFERENCES SANPHAM(MASP),
	SL INT,
	PRIMARY KEY (SOHD, MASP)
)
GO

-- 2.	Thêm vào thuộc tính GHICHU có kiểu dữ liệu varchar(20) cho quan hệ SANPHAM.
ALTER TABLE SANPHAM ADD GHICHU VARCHAR(20)
GO

-- 3.	Thêm vào thuộc tính LOAIKH có kiểu dữ liệu là tinyint cho quan hệ KHACHHANG.
ALTER TABLE KHACHHANG ADD LOAIKH TINYINT
GO

-- 4.	Sửa kiểu dữ liệu của thuộc tính GHICHU trong quan hệ SANPHAM thành varchar(100).
ALTER TABLE SANPHAM ALTER COLUMN GHICHU VARCHAR(100)
GO

-- 5.	Xóa thuộc tính GHICHU trong quan hệ SANPHAM.
ALTER TABLE SANPHAM DROP COLUMN GHICHU
GO

-- 6.	Làm thế nào để thuộc tính LOAIKH trong quan hệ KHACHHANG có thể lưu các giá trị là: “Vang lai”, “Thuong xuyen”, “Vip”, …
ALTER TABLE KHACHHANG ALTER COLUMN LOAIKH VARCHAR(20)
GO

-- 7.	Đơn vị tính của sản phẩm chỉ có thể là (“cay”,”hop”,”cai”,”quyen”,”chuc”)
ALTER TABLE SANPHAM ADD CONSTRAINT CK_DVT CHECK(DVT in ('cay', 'hop', 'cai', 'quyen', 'chuc'))
GO

-- 8.	Giá bán của sản phẩm từ 500 đồng trở lên.
ALTER TABLE SANPHAM ADD CONSTRAINT CK_GIA CHECK(GIA >= 500)
GO

-- 9.	Mỗi lần mua hàng, khách hàng phải mua ít nhất 1 sản phẩm.
ALTER TABLE CTHD ADD CONSTRAINT CK_SL CHECK(SL >= 1)
GO

-- 10.	Ngày khách hàng đăng ký là khách hàng thành viên phải lớn hơn ngày sinh của người đó.
ALTER TABLE KHACHHANG ADD CONSTRAINT CK_NGDK CHECK(NGDK > NGSINH)
GO


-- II. Ngôn ngữ thao tác dữ liệu (Data Manipulation Language):
-- 1. Nhập dữ liệu cho các quan hệ trên.

-------------------------------- KHACHHANG --------------------------------------------
INSERT INTO KHACHHANG(MAKH,HOTEN,DCHI,SODT,NGSINH,DOANHSO,NGDK)
VALUES	
		('KH01' , 'Nguyen Van A', '731 Tran Hung Dao, Q5, TpHCM', '08823451', '1960-10-22', 13060000, '2006-07-22'),
		('KH02' ,'Tran Ngoc Han' ,'23/5 Nguyen Trai, Q5, TpHCM','0908256478', '1974-03-04' , 280000, '2006-07-30'),
		('KH03', 'Tran Ngoc Linh', '45 Nguyen Canh Chan, Q1, TpHCM', '0938776266', '1980-12-06', 3860000, '2006-08-05'),
		('KH04', 'Tran Minh Long', '50/34 Le Dai Hanh, Q10, TpHCM', '0917325476', '1965-09-03', 250000, '2006-10-02'),
		('KH05', 'Le Nhat Minh', '34 Truong Dinh, Q3, TpHCM', '08246108', '1950-10-03', 21000, '2006-10-28'),
		('KH06', 'Le Hoai Thuong', '227 Nguyen Van Cu, Q5, TpHCM', '08631738', '1981-12-31', 915000, '2006-11-24'),
		('KH07', 'Nguyen Van Tam', '32/3 Tran Binh Trong, Q5, TpHCM', '0916783565', '1971-06-04', 12500, '2006-12-01'),
		('KH08', 'Phan Thi Thanh', '45/2 An Duong Vuong, Q5, TpHCM', '0938435756', '1971-10-01', 365000, '2006-12-13'),
		('KH09', 'Le Ha Vinh', '873 Le Hong Phong, Q5, TpHCM', '08654763', '1979-03-09', 70000, '2007-01-14'),
		('KH10', 'Ha Duy Lap', '34/34B Nguyen Trai, Q1, TpHCM', '08768904', '1983-02-05', 67500, '2007-01-16');
--------------------------------- SANPHAM ---------------------------------------------

INSERT INTO SANPHAM 
VALUES ('BC01', 'But chi', 'cay', 'Singapore', 3000)
INSERT INTO SANPHAM 
VALUES ('BC02', 'But chi', 'cay', 'Singapore', 5000)
INSERT INTO SANPHAM 
VALUES ('BC03', 'But chi', 'cay', 'Viet Nam', 3500)
INSERT INTO SANPHAM 
VALUES ('BC04', 'But chi', 'hop', 'Viet Nam', 30000)
INSERT INTO SANPHAM 
VALUES ('BB01', 'But bi', 'cay', 'Viet Nam', 5000)
INSERT INTO SANPHAM 
VALUES ('BB02', 'But bi', 'cay', 'Trung Quoc', 7000)
INSERT INTO SANPHAM 
VALUES ('BB03', 'But chi', 'cay', 'Thai Lan', 100000)
INSERT INTO SANPHAM 
VALUES ('TV01', 'Tap 100 giay mong', 'quyen', 'Trung Quoc', 2500)
INSERT INTO SANPHAM(MASP, TENSP, DVT, NUOCSX, GIA)
VALUES	('TV02', 'Tap 200 giay mong', 'quyen', 'Trung Quoc', 4500),
		('TV03', 'Tap 100 giay tot', 'quyen', 'Viet Nam', 3000),
		('TV04', 'Tap 200 giay tot', 'quyen', 'Viet Nam', 5500),
		('TV05', 'Tap 100 trang', 'chuc' ,'Viet Nam' ,23000),
		('TV06', 'Tap 200 trang', 'chuc' ,'Viet Nam' ,53000),
		('TV07', 'Tap 100 trang', 'chuc' ,'Trung Quoc' ,34000),
		('ST01', 'So tay 500 trang', 'quyen' ,'Trung Quoc' ,40000),
		('ST02', 'So tay loai 1', 'quyen' ,'Viet Nam' ,55000),
		('ST03', 'So tay loai 2', 'quyen' ,'Viet Nam' ,51000),
		('ST04', 'So tay', 'quyen' ,'Thai Lan' ,55000),
		('ST05', 'So tay mong', 'quyen' ,'Thai Lan' ,20000),
		('ST06', 'Phan viet bang', 'hop' ,'Viet Nam' ,5000),
		('ST07', 'Phan khong bui', 'hop' ,'Viet Nam' ,7000),
		('ST08', 'Bong bang', 'cai' ,'Viet Nam' ,1000),
		('ST09', 'But long', 'cay' ,'Viet Nam' ,5000),
		('ST10', 'But long', 'cay' ,'Trung Quoc' ,7000);
--------------------------------- NHANVIEN --------------------------------------------

INSERT INTO NHANVIEN
VALUES ('NV01','Nguyen Nhu Nhut', 0927345678, '2006-4-13')
INSERT INTO NHANVIEN
VALUES ('NV02','Le Thi Phi Yen', 0987567390, '2006-4-21')
INSERT INTO NHANVIEN
VALUES ('NV03','Nguyen Van B', 0997047382, '2006-4-27')
INSERT INTO NHANVIEN
VALUES ('NV04','Ngo Thanh Tuan', 0913758498, '2006-6-24')
INSERT INTO NHANVIEN
VALUES ('NV05','Nguyen Thi Truc Thanh', 0918590387, '2006-7-20')

---------------------------------- HOADON ---------------------------------------------


INSERT INTO HOADON(SOHD, NGHD, MAKH, MANV, TRIGIA)
VALUES
	(1001, '2006-7-23', 'KH01', 'NV01', 320000),
	(1002, '2006-8-12', 'KH01', 'NV02', 840000),
	(1003, '2006-8-23', 'KH02', 'NV01', 100000),
	(1004, '2006-9-1', 'KH02', 'NV01', 180000),
	(1005, '2006-10-20', 'KH01', 'NV02', 3800000),
	(1006, '2006-10-16', 'KH01', 'NV03', 2430000),
	(1007, '2006-10-28', 'KH03', 'NV03', 510000),
	(1008, '2006-10-28', 'KH01', 'NV03', 4400000),
	(1009,'2006-10-28', 'KH03', 'NV04', 200000),
	(1010, '2006-11-1', 'KH01', 'NV01', 5200000),
	(1011, '2006-11-4', 'KH04', 'NV03', 250000),
	(1012, '2006-11-30', 'KH05', 'NV03', 21000),
	(1013, '2006-12-12', 'KH06', 'NV01', 5000),
	(1014, '2006-12-31', 'KH03', 'NV02', 3150000),
	(1015, '2007-1-1', 'KH06', 'NV01', 910000),
	(1016, '2007-1-1', 'KH07', 'NV02', 1500),
	(1017, '2007-1-2', 'KH08', 'NV03', 35000),
	(1018, '2007-1-13', 'KH08', 'NV03', 330000),
	(1019, '2007-1-13', 'KH01', 'NV03', 30000),
	(1020, '2007-1-14', 'KH09', 'NV04', 70000),
	(1021, '2007-1-16', 'KH10', 'NV03', 67500),
	(1022, '2007-1-16', Null, 'NV03', 7000),
	(1023, '2007-01-17', Null, 'NV01', 330000);
	
----------------------------------- CTHD ----------------------------------------------
INSERT INTO CTHD(SOHD,MASP,SL)
VALUES	(1001 , 'TV02', 10),
		(1001 , 'ST01', 5),
		(1001 , 'BC01', 5),
		(1001 , 'BC02', 10),
		(1001 , 'ST08', 10),
		(1002 , 'BC04', 20),
		(1002 , 'BB01', 20),
		(1002 , 'BB02', 20),
		(1003 , 'BB03', 10),
		(1004 , 'TV01', 20),
		(1004 , 'TV02', 10),
		(1004 , 'TV03', 10),
		(1004 , 'TV04', 10),
		(1005 , 'TV05', 50),
		(1005 , 'TV06', 50),
		(1006 , 'TV07', 20),
		(1006, 'ST01', 30),
		(1006, 'ST02', 10),
		(1007, 'ST03', 10),
		(1008, 'ST04', 8),
		(1009, 'ST05', 10),
		(1010, 'TV07', 50),
		(1010, 'ST08', 100),
		(1010, 'ST04', 50),
		(1010, 'TV03', 100),
		(1011, 'ST06', 50),
		(1012, 'ST07', 3),
		(1013, 'ST08', 5),
		(1014, 'BC02', 80),
		(1014, 'BB02', 100),
		(1014, 'BC04', 60),
		(1014, 'BB01', 50),
		(1015, 'BB02', 30),
		(1015, 'BB03', 7),
		(1016, 'TV01', 5),
		(1017, 'TV02', 1),
		(1017, 'TV03', 1),
		(1017, 'TV04', 5),
		(1018, 'ST04', 6),
		(1019, 'ST05', 1),
		(1019, 'ST06', 2),
		(1020, 'ST07', 10),
		(1021, 'ST08', 5),
		(1021, 'TV01', 7),
		(1021, 'TV02', 10),
		(1022, 'ST07', 1),
		(1023, 'ST04', 6);
-- 2.	Tạo quan hệ SANPHAM1 chứa toàn bộ dữ liệu của quan hệ SANPHAM. Tạo quan hệ KHACHHANG1 chứa toàn bộ dữ liệu của quan hệ KHACHHANG.
SELECT * INTO SANPHAM1 FROM SANPHAM
SELECT * INTO KHACHHANG1 FROM KHACHHANG

-- DROP TABLE SANPHAM1
-- DROP TABLE KHACHHANG1

-- DELETE FROM SANPHAM1
-- DELETE FROM KHACHHANG1

-- SELECT * FROM SANPHAM1
-- SELECT * FROM KHACHHANG1
GO
-- 3.	Cập nhật giá tăng 5% đối với những sản phẩm do “Thai Lan” sản xuất (cho quan hệ SANPHAM1)
UPDATE SANPHAM1 SET GIA += GIA * 0.05 
WHERE NUOCSX = 'Thai Lan' 
GO
-- 4.	Cập nhật giá giảm 5% đối với những sản phẩm do “Trung Quoc” sản xuất có giá từ 10.000 trở xuống (cho quan hệ SANPHAM1).
UPDATE SANPHAM1 SET GIA -= GIA * 0.05 
WHERE NUOCSX = 'Trung Quoc' AND GIA <= 10000
GO

/* 5.	Cập nhật giá trị LOAIKH là “Vip” đối với những khách hàng đăng ký thành viên trước ngày 1/1/2007 có doanh số từ 
10.000.000 trở lên hoặc khách hàng đăng ký thành viên từ 1/1/2007 trở về sau có doanh số từ 2.000.000 trở lên (cho quan hệ KHACHHANG1) */
UPDATE KHACHHANG1 SET LOAIKH = 'VIP' 
WHERE (NGDK < '1/1/2007' AND DOANHSO >= 10000000) OR (NGDK > '1/1/2007' AND DOANHSO >= 2000000)
GO

------------------------------ III. Ngôn ngữ truy vấn dữ liệu có cấu trúc:

-- 1.	In ra danh sách các sản phẩm (MASP,TENSP) do “Trung Quoc” sản xuất.
SELECT MASP, TENSP FROM SANPHAM 
WHERE NUOCSX = 'Trung Quoc'
GO

-- 2.	In ra danh sách các sản phẩm (MASP,TENSP) có đơn vị tính là “cay”, ”quyen”.
SELECT MASP, TENSP FROM SANPHAM 
WHERE DVT IN ('cay', 'quyen')
GO

-- 3.	In ra danh sách các sản phẩm (MASP,TENSP) có mã sản phẩm bắt đầu là “B” và kết thúc là “01”.
SELECT MASP, TENSP FROM SANPHAM 
WHERE LEFT(MASP, 1) = 'B' AND RIGHT(MASP, 2) = '01'
GO

-- 4.	In ra danh sách các sản phẩm (MASP,TENSP) do “Trung Quốc” sản xuất có giá từ 30.000 đến 40.000.
SELECT MASP, TENSP FROM SANPHAM 
WHERE NUOCSX = 'Trung Quoc' AND GIA BETWEEN 30000 AND 40000
GO

-- 5.	In ra danh sách các sản phẩm (MASP,TENSP) do “Trung Quoc” hoặc “Thai Lan” sản xuất có giá từ 30.000 đến 40.000.
SELECT MASP,TENSP FROM SANPHAM 
WHERE (NUOCSX IN ('Trung Quoc', ' Thai Lan')) AND (GIA BETWEEN 30000 AND 40000)
GO

-- 6.	In ra các số hóa đơn, trị giá hóa đơn bán ra trong ngày 1/1/2007 và ngày 2/1/2007.
SELECT SOHD, TRIGIA FROM HOADON 
WHERE NGHD IN ('1/1/2007', '2/1/2007')
GO

-- 7.	In ra các số hóa đơn, trị giá hóa đơn trong tháng 1/2007, sắp xếp theo ngày (tăng dần) và trị giá của hóa đơn (giảm dần).
SELECT SOHD, TRIGIA FROM HOADON 
WHERE YEAR(NGHD) = 2007 AND MONTH(NGHD) = 1 
ORDER BY NGHD ASC, TRIGIA DESC
GO

-- 8.	In ra danh sách các khách hàng (MAKH, HOTEN) đã mua hàng trong ngày 1/1/2007.
SELECT HD.MAKH, HOTEN
FROM HOADON HD INNER JOIN KHACHHANG KH 
ON HD.MAKH = KH.MAKH 
WHERE NGHD = '1/1/2007'
GO

-- 9.	In ra số hóa đơn, trị giá các hóa đơn do nhân viên có tên “Nguyen Van B” lập trong ngày 28/10/2006.
SELECT HD.SOHD, TRIGIA 
FROM HOADON HD INNER JOIN NHANVIEN NV 
ON HD.MANV = NV.MANV 
WHERE HOTEN = 'Nguyen Van B' AND NGHD = '10/28/2006'
GO

-- 10.	In ra danh sách các sản phẩm (MASP,TENSP) được khách hàng có tên “Nguyen Van A” mua trong tháng 10/2006.
SELECT CT.MASP, TENSP 
FROM CTHD CT INNER JOIN SANPHAM SP 
ON CT.MASP = SP.MASP
WHERE SOHD IN (
	SELECT SOHD 
	FROM HOADON HD INNER JOIN KHACHHANG KH 
	ON HD.MAKH = KH.MAKH
	WHERE HOTEN = 'Nguyen Van A' AND YEAR(NGHD) = 2006 AND MONTH(NGHD) = 10 
)
GO

-- 11.	Tìm các số hóa đơn đã mua sản phẩm có mã số “BB01” hoặc “BB02”.
SELECT SOHD FROM CTHD WHERE MASP = 'BB01' 
UNION
SELECT SOHD FROM CTHD WHERE MASP = 'BB02' 
GO

-- III. Ngôn ngữ truy vấn dữ liệu có cấu trúc: ------------------------LAB 3----------------------------------------

-- 12.	Tìm các số hóa đơn đã mua sản phẩm có mã số “BB01” hoặc “BB02”, mỗi sản phẩm mua với số lượng từ 10 đến 20.
SELECT DISTINCT SOHD FROM CTHD 
WHERE MASP IN ('BB01', 'BB02') AND SL BETWEEN 10 AND 20
GO

-- 13.	Tìm các số hóa đơn mua cùng lúc 2 sản phẩm có mã số “BB01” và “BB02”, mỗi sản phẩm mua với số lượng từ 10 đến 20.
SELECT SOHD FROM CTHD 
WHERE MASP IN ('BB01', 'BB02') AND SL BETWEEN 10 AND 20
GROUP BY SOHD 
HAVING COUNT(DISTINCT MASP) = 2
GO

-- 14.	In ra danh sách các sản phẩm (MASP,TENSP) do “Trung Quoc” sản xuất hoặc các sản phẩm được bán ra trong ngày 1/1/2007.
SELECT MASP, TENSP
FROM SANPHAM 
WHERE NUOCSX = 'Trung Quoc' OR MASP IN (
	SELECT DISTINCT CT.MASP 
	FROM CTHD CT INNER JOIN HOADON HD
	ON CT.SOHD = HD.SOHD
	WHERE NGHD = '01/01/2007'
)
GO

-- 15.	In ra danh sách các sản phẩm (MASP,TENSP) không bán được.
SELECT MASP, TENSP
FROM SANPHAM 
WHERE MASP NOT IN (
	SELECT DISTINCT MASP 
	FROM CTHD
)
GO

-- 16.	In ra danh sách các sản phẩm (MASP,TENSP) không bán được trong năm 2006.
SELECT MASP, TENSP
FROM SANPHAM 
WHERE MASP NOT IN (
	SELECT CT.MASP
	FROM CTHD CT INNER JOIN HOADON HD
	ON CT.SOHD = HD.SOHD
	WHERE YEAR(NGHD) = 2006
)
GO

-- 17.	In ra danh sách các sản phẩm (MASP,TENSP) do “Trung Quoc” sản xuất không bán được trong năm 2006.
SELECT MASP, TENSP
FROM SANPHAM 
WHERE NUOCSX = 'Trung Quoc' AND MASP NOT IN (
	SELECT DISTINCT CT.MASP
	FROM CTHD CT INNER JOIN HOADON HD
	ON CT.SOHD = HD.SOHD
	WHERE YEAR(NGHD) = 2006
)
GO
-- SELECT * FROM SANPHAM

-- 18.	Tìm số hóa đơn đã mua tất cả các sản phẩm do Singapore sản xuất.
SELECT CT.SOHD
FROM CTHD CT INNER JOIN SANPHAM SP
ON CT.MASP = SP.MASP
WHERE NUOCSX = 'Singapore'
GROUP BY CT.SOHD 
HAVING COUNT(DISTINCT CT.MASP) = (
	SELECT COUNT(MASP) 
	FROM SANPHAM 
	WHERE NUOCSX = 'Singapore'
)
GO


-- 19.	Tìm số hóa đơn trong năm 2006 đã mua ít nhất tất cả các sản phẩm do Singapore sản xuất.
SELECT SOHD 
FROM HOADON
WHERE YEAR(NGHD) = 2006 AND SOHD IN (
	SELECT CT.SOHD
	FROM CTHD CT INNER JOIN SANPHAM SP
	ON CT.MASP = SP.MASP
	WHERE NUOCSX = 'Singapore'
	GROUP BY CT.SOHD 
	HAVING COUNT(DISTINCT CT.MASP) = (
		SELECT COUNT(MASP) 
		FROM SANPHAM 
		WHERE NUOCSX = 'Singapore'
	)
)
GO
----------------------------------------------LAB 4-------------------------------------------
-- 20.	Có bao nhiêu hóa đơn không phải của khách hàng đăng ký thành viên mua?
SELECT COUNT(*) FROM HOADON
WHERE MAKH NOT IN(
	SELECT MAKH FROM KHACHHANG 
	WHERE KHACHHANG.MAKH = HOADON.MAKH
)
GO

-- 21.	Có bao nhiêu sản phẩm khác nhau được bán ra trong năm 2006.
SELECT COUNT(DISTINCT MASP) 
FROM CTHD CT INNER JOIN HOADON HD
ON CT.SOHD = HD.SOHD
WHERE YEAR(NGHD) = '2006'
GO

-- 22.	Cho biết trị giá hóa đơn cao nhất, thấp nhất là bao nhiêu ?
SELECT MIN(TRIGIA) GIAMIN, MAX(TRIGIA) GIAMAX FROM HOADON
GO

-- 23.	Trị giá trung bình của tất cả các hóa đơn được bán ra trong năm 2006 là bao nhiêu?
SELECT AVG(TRIGIA) FROM HOADON WHERE YEAR(NGHD) = '2006'
GO

-- 24.	Tính doanh thu bán hàng trong năm 2006.
SELECT SUM(TRIGIA) FROM HOADON WHERE YEAR(NGHD) = '2006'
GO

-- 25.	Tìm số hóa đơn có trị giá cao nhất trong năm 2006.
SELECT SOHD FROM HOADON
WHERE YEAR(NGHD) = '2006' AND TRIGIA = (
	SELECT MAX(TRIGIA) FROM HOADON
)
GO

-- 26.	Tìm họ tên khách hàng đã mua hóa đơn có trị giá cao nhất trong năm 2006.
SELECT HOTEN FROM HOADON HD INNER JOIN KHACHHANG KH
ON HD.MAKH = KH.MAKH
WHERE YEAR(NGHD) = '2006' AND TRIGIA = (
	SELECT MAX(TRIGIA) FROM HOADON
)
GO

-- 27.	In ra danh sách 3 khách hàng (MAKH, HOTEN) có doanh số cao nhất.
SELECT TOP 3 MAKH, HOTEN FROM KHACHHANG ORDER BY DOANHSO DESC
GO

-- 28.	In ra danh sách các sản phẩm (MASP, TENSP) có giá bán bằng 1 trong 3 mức giá cao nhất.
SELECT MASP, TENSP FROM SANPHAM
WHERE GIA IN(
	SELECT DISTINCT TOP 3 GIA FROM SANPHAM
	ORDER BY GIA DESC
)
GO

-- 29.	In ra danh sách các sản phẩm (MASP, TENSP) do “Thai Lan” sản xuất có giá bằng 1 trong 3 mức giá cao nhất (của tất cả các sản phẩm).
SELECT MASP, TENSP FROM SANPHAM
WHERE NUOCSX = 'Thai Lan' AND GIA IN(
	SELECT DISTINCT TOP 3 GIA FROM SANPHAM
	ORDER BY GIA DESC
)
GO

-- 30.	In ra danh sách các sản phẩm (MASP, TENSP) do “Trung Quoc” sản xuất có giá bằng 1 trong 3 mức giá cao nhất (của sản phẩm do “Trung Quoc” sản xuất).
SELECT MASP, TENSP FROM SANPHAM
WHERE NUOCSX = 'Trung Quoc' AND GIA IN(
	SELECT DISTINCT TOP 3 GIA FROM SANPHAM
	WHERE NUOCSX = 'Trung Quoc'
	ORDER BY GIA DESC
)
GO

-- 31.	* In ra danh sách 3 khách hàng có doanh số cao nhất (sắp xếp theo kiểu xếp hạng).
SELECT TOP 3 MAKH, HOTEN, RANK() OVER (ORDER BY DOANHSO DESC) RANK_KH FROM KHACHHANG
GO

-- 32.	Tính tổng số sản phẩm do “Trung Quoc” sản xuất.
SELECT COUNT(MASP) FROM SANPHAM WHERE NUOCSX = 'Trung Quoc'
GO

-- 33.	Tính tổng số sản phẩm của từng nước sản xuất.
SELECT NUOCSX, COUNT(MASP) SOSP FROM SANPHAM GROUP BY NUOCSX
GO

-- 34.	Với từng nước sản xuất, tìm giá bán cao nhất, thấp nhất, trung bình của các sản phẩm.
SELECT NUOCSX, MAX(GIA) GIAMAX, MIN(GIA) GIAMIN, AVG(GIA) TRUNGBINH FROM SANPHAM GROUP BY NUOCSX
GO

-- 35.	Tính doanh thu bán hàng mỗi ngày.
SELECT NGHD, SUM(TRIGIA) DOANHTHU FROM HOADON GROUP BY NGHD
GO

-- 36.	Tính tổng số lượng của từng sản phẩm bán ra trong tháng 10/2006.
SELECT  CT.MASP, SUM(SL) SL
FROM CTHD CT INNER JOIN HOADON HD 
ON CT.SOHD = HD.SOHD
WHERE YEAR(NGHD) = '2006' AND MONTH(NGHD) = '10'
GROUP BY CT.MASP
GO

-- 37.	Tính doanh thu bán hàng của từng tháng trong năm 2006.
SELECT MONTH(NGHD) THANG, SUM(TRIGIA) DOANHTHU
FROM HOADON 
WHERE YEAR(NGHD) = '2006'
GROUP BY MONTH(NGHD)
GO

-- 38.	Tìm hóa đơn có mua ít nhất 4 sản phẩm khác nhau.
SELECT SOHD FROM CTHD
GROUP BY SOHD 
HAVING COUNT(DISTINCT MASP) >= 4
GO

-- 39.	Tìm hóa đơn có mua 3 sản phẩm do “Viet Nam” sản xuất (3 sản phẩm khác nhau).
SELECT SOHD FROM CTHD CT INNER JOIN SANPHAM SP
ON CT.MASP = SP.MASP
WHERE NUOCSX = 'Viet Nam'
GROUP BY SOHD 
HAVING COUNT(DISTINCT CT.MASP) = 3
GO

-- 40.	Tìm khách hàng (MAKH, HOTEN) có số lần mua hàng nhiều nhất. 
SELECT MAKH, HOTEN FROM (
	SELECT HD.MAKH, HOTEN, RANK() OVER (ORDER BY COUNT(HD.MAKH) DESC) RANK_SOLAN 
	FROM HOADON HD INNER JOIN KHACHHANG KH 
	ON HD.MAKH = KH.MAKH
	GROUP BY HD.MAKH, HOTEN
) A
WHERE RANK_SOLAN = 1
GO

-- 41.	Tháng mấy trong năm 2006, doanh số bán hàng cao nhất ?
SELECT THANG FROM (
	SELECT MONTH(NGHD) THANG, RANK() OVER (ORDER BY SUM(TRIGIA) DESC) RANK_TRIGIA FROM HOADON
	WHERE YEAR(NGHD) = '2006' 
	GROUP BY MONTH(NGHD)
) A
WHERE RANK_TRIGIA = 1
GO

-- 42.	Tìm sản phẩm (MASP, TENSP) có tổng số lượng bán ra thấp nhất trong năm 2006.
SELECT A.MASP, TENSP FROM (
	SELECT MASP, RANK() OVER (ORDER BY SUM(SL)) RANK_SL
	FROM CTHD CT INNER JOIN HOADON HD
	ON CT.SOHD = HD.SOHD
	WHERE YEAR(NGHD) = '2006'
	GROUP BY MASP
) A INNER JOIN SANPHAM SP
ON A.MASP = SP.MASP
WHERE RANK_SL = 1
GO

-- 43.	*Mỗi nước sản xuất, tìm sản phẩm (MASP,TENSP) có giá bán cao nhất.
SELECT NUOCSX, MASP, TENSP FROM (
	SELECT NUOCSX, MASP, TENSP, GIA, RANK() OVER (PARTITION BY NUOCSX ORDER BY GIA DESC) RANK_GIA FROM SANPHAM
) A 
WHERE RANK_GIA = 1
GO

-- 44.	Tìm nước sản xuất sản xuất ít nhất 3 sản phẩm có giá bán khác nhau.
SELECT NUOCSX FROM SANPHAM 
GROUP BY NUOCSX
HAVING COUNT(DISTINCT GIA) >= 3
GO

-- 45.	*Trong 10 khách hàng có doanh số cao nhất, tìm khách hàng có số lần mua hàng nhiều nhất.
SELECT MAKH, HOTEN FROM (
	SELECT TOP 10 HD.MAKH, HOTEN, DOANHSO, RANK() OVER (ORDER BY COUNT(HD.MAKH) DESC) RANK_SOLAN 
	FROM HOADON HD INNER JOIN KHACHHANG KH 
	ON HD.MAKH = KH.MAKH
	GROUP BY HD.MAKH, HOTEN, DOANHSO
	ORDER BY DOANHSO DESC
) A
WHERE RANK_SOLAN = 1
GO

----------------------------------------------------LAB 5------------------------------------------------

-- I. Ngôn ngữ định nghĩa dữ liệu (Data Definition Language):
-- 11.	Ngày mua hàng (NGHD) của một khách hàng thành viên sẽ lớn hơn hoặc bằng ngày khách hàng đó đăng ký thành viên (NGDK).
CREATE TRIGGER TRG_HD_KH ON HOADON FOR INSERT
AS
BEGIN
	DECLARE @NGHD SMALLDATETIME, @NGDK SMALLDATETIME, @MAKH CHAR(4)
	SELECT @NGHD = NGHD, @MAKH = MAKH FROM INSERTED
	SELECT	@NGDK = NGDK FROM KHACHHANG WHERE MAKH = @MAKH

	PRINT @NGHD 
	PRINT @NGDK

	IF (@NGHD >= @NGDK)
		PRINT N'Thêm mới một hóa đơn thành công.'
	ELSE
	BEGIN
		PRINT N'Lỗi: Ngày mua hàng của một khách hàng thành viên sẽ lớn hơn hoặc bằng ngày khách hàng đó đăng ký thành viên.'
		ROLLBACK TRANSACTION
	END
END
GO



-- 12.	Ngày bán hàng (NGHD) của một nhân viên phải lớn hơn hoặc bằng ngày nhân viên đó vào làm.
CREATE TRIGGER TRG_HD_NV ON HOADON FOR INSERT
AS
BEGIN
	DECLARE @NGHD SMALLDATETIME, @NGVL SMALLDATETIME, @MANV CHAR(4)
	SELECT @NGHD = NGHD, @MANV = MANV FROM INSERTED
	SELECT	@NGVL = NGVL FROM NHANVIEN WHERE MANV = @MANV

	IF (@NGHD >= @NGVL)
		PRINT N'Thêm mới một hóa đơn thành công.'
	ELSE
	BEGIN
		PRINT N'Lỗi: Ngày bán hàng của một nhân viên phải lớn hơn hoặc bằng ngày nhân viên đó vào làm.'
		ROLLBACK TRANSACTION
	END
END
GO

-- 13.	Mỗi một hóa đơn phải có ít nhất một chi tiết hóa đơn.
CREATE TRIGGER TRG_HD_CTHD ON HOADON FOR INSERT
AS
BEGIN
	DECLARE @SOHD INT, @COUNT_SOHD INT
	SELECT @SOHD = SOHD FROM INSERTED
	SELECT @COUNT_SOHD = COUNT(SOHD) FROM CTHD WHERE SOHD = @SOHD

	IF (@COUNT_SOHD >= 1)
		PRINT N'Thêm mới một hóa đơn thành công.'
	ELSE
	BEGIN
		PRINT N'Lỗi: Mỗi một hóa đơn phải có ít nhất một chi tiết hóa đơn.'
		ROLLBACK TRANSACTION
	END
END
GO

-- 14.	Trị giá của một hóa đơn là tổng thành tiền (số lượng*đơn giá) của các chi tiết thuộc hóa đơn đó.
CREATE TRIGGER TRG_CTHD ON CTHD FOR INSERT, DELETE
AS
BEGIN
	DECLARE @SOHD INT, @TONGGIATRI INT

	SELECT @TONGGIATRI = SUM(SL * GIA), @SOHD = SOHD 
	FROM INSERTED INNER JOIN SANPHAM
	ON INSERTED.MASP = SANPHAM.MASP
	GROUP BY SOHD

	UPDATE HOADON
	SET TRIGIA += @TONGGIATRI
	WHERE SOHD = @SOHD
END
GO 

CREATE TRIGGER TR_DEL_CTHD ON CTHD FOR DELETE
AS
BEGIN
	DECLARE @SOHD INT, @GIATRI INT

	SELECT @SOHD = SOHD, @GIATRI = SL * GIA 
	FROM DELETED INNER JOIN SANPHAM 
	ON SANPHAM.MASP = DELETED.MASP

	UPDATE HOADON
	SET TRIGIA -= @GIATRI
	WHERE SOHD = @SOHD
END
GO
/*
SELECT * FROM KHACHHANG
SELECT * FROM NHANVIEN
SELECT * FROM SANPHAM
SELECT * FROM HOADON
SELECT * FROM CTHD

DROP TABLE KHACHHANG
DROP TABLE NHANVIEN
DROP TABLE SANPHAM
DROP TABLE HOADON
DROP TABLE CTHD
*/
-------------------------------- QUANLYHOCVU ------------------------------------------
/*
DROP TABLE KHOA 
DROP TABLE MONHOC 
DROP TABLE DIEUKIEN 
DROP TABLE GIAOVIEN  
DROP TABLE LOP 
DROP TABLE HOCVIEN 
DROP TABLE GIANGDAY  
DROP TABLE KETQUATHI  

DELETE FROM KHOA 
DELETE FROM MONHOC 
DELETE FROM DIEUKIEN
DELETE FROM GIAOVIEN
DELETE FROM LOP
DELETE FROM HOCVIEN
DELETE FROM GIANGDAY
DELETE FROM KETQUATHI

SELECT * FROM KHOA 
SELECT * FROM MONHOC 
SELECT * FROM DIEUKIEN
SELECT * FROM GIAOVIEN
SELECT * FROM LOP
SELECT * FROM HOCVIEN
SELECT * FROM GIANGDAY
SELECT * FROM KETQUATHI
*/
GO

-- I. Ngôn ngữ định nghĩa dữ liệu (Data Definition Language):
-- 1.	Tạo quan hệ và khai báo tất cả các ràng buộc khóa chính, khóa ngoại. Thêm vào 3 thuộc tính GHICHU, DIEMTB, XEPLOAI cho quan hệ HOCVIEN.
USE master
IF EXISTS (SELECT * FROM SYS.DATABASES WHERE NAME = 'QUANLYHOCVU')
BEGIN
	ALTER DATABASE QUANLYHOCVU SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE QUANLYHOCVU;
END
GO

CREATE DATABASE QUANLYHOCVU
GO

USE QUANLYHOCVU
GO

----------------------------------- KHOA ----------------------------------------------
CREATE TABLE KHOA
(
	MAKHOA VARCHAR(4) PRIMARY KEY,
	TENKHOA VARCHAR(40),
	NGTLAP SMALLDATETIME,
	TRGKHOA CHAR(4)
)
GO

---------------------------------- MONHOC ---------------------------------------------
CREATE TABLE MONHOC
(
	MAMH VARCHAR(10) PRIMARY KEY,
	TENMH VARCHAR(40),
	TCLT TINYINT,
	TCTH TINYINT,
	MAKHOA VARCHAR(4) FOREIGN KEY REFERENCES KHOA(MAKHOA)
)
GO

--------------------------------- DIEUKIEN --------------------------------------------
CREATE TABLE DIEUKIEN
(
	MAMH VARCHAR(10) FOREIGN KEY REFERENCES MONHOC(MAMH),
	MAMH_TRUOC VARCHAR(10),
	PRIMARY KEY (MAMH, MAMH_TRUOC)
)
GO

--------------------------------- GIAOVIEN --------------------------------------------
CREATE TABLE GIAOVIEN
(
	MAGV CHAR(4) PRIMARY KEY,
	HOTEN VARCHAR(40),
	HOCVI VARCHAR(10),
	HOCHAM VARCHAR(10),
	GIOITINH VARCHAR(3),
	NGSINH SMALLDATETIME,
	NGVL SMALLDATETIME,
	HESO NUMERIC(4,2),
	MUCLUONG MONEY,
	MAKHOA VARCHAR(4) FOREIGN KEY REFERENCES KHOA(MAKHOA)
)
GO

----------------------------------- LOP -----------------------------------------------
CREATE TABLE LOP
(
	MALOP CHAR(3) PRIMARY KEY,
	TENLOP VARCHAR(40),
	TRGLOP CHAR(5),
	SISO TINYINT,
	MAGVCN CHAR(4) FOREIGN KEY REFERENCES GIAOVIEN(MAGV)
)
GO

--------------------------------- HOCVIEN ---------------------------------------------
CREATE TABLE HOCVIEN
(
	MAHV CHAR(5) PRIMARY KEY,
	HO VARCHAR(40),
	TEN VARCHAR(10),
	NGSINH SMALLDATETIME,
	GIOITINH VARCHAR(3),
	NOISINH VARCHAR(40),
	MALOP CHAR(3) FOREIGN KEY REFERENCES LOP(MALOP) 
)
GO

--------------------------------- GIANGDAY --------------------------------------------
CREATE TABLE GIANGDAY
(
	MALOP CHAR(3) FOREIGN KEY REFERENCES LOP(MALOP),
	MAMH VARCHAR(10) FOREIGN KEY REFERENCES MONHOC(MAMH),
	MAGV CHAR(4) FOREIGN KEY REFERENCES GIAOVIEN(MAGV),
	HOCKY TINYINT,
	NAM SMALLINT,
	TUNGAY SMALLDATETIME,
	DENNGAY SMALLDATETIME,
	PRIMARY KEY (MALOP, MAMH)
)
GO

--------------------------------- KETQUATHI -------------------------------------------
CREATE TABLE KETQUATHI
(
	MAHV CHAR(5) FOREIGN KEY REFERENCES HOCVIEN(MAHV),
	MAMH VARCHAR(10) FOREIGN KEY REFERENCES MONHOC(MAMH),
	LANTHI TINYINT,
	NGTHI SMALLDATETIME,
	DIEM NUMERIC(4,2),
	KQUA VARCHAR(10),
	PRIMARY KEY (MAHV, MAMH, LANTHI)
)
GO

ALTER TABLE KHOA ADD CONSTRAINT FK__KHOA__TRGKHOA FOREIGN KEY (TRGKHOA) REFERENCES GIAOVIEN(MAGV)
Go


-- 2.	Mã học viên là một chuỗi 5 ký tự, 3 ký tự đầu là mã lớp, 2 ký tự cuối cùng là số thứ tự học viên trong lớp. VD: “K1101”
CREATE FUNCTION check_valid_MALOP (@MAHV VARCHAR(5))
RETURNs TINYINT
AS 
BEGIN
	IF LEFT(@MAHV, 3) IN (SELECT MALOP FROM LOP)
		RETURN 1
	RETURN 0
END
GO

CREATE FUNCTION check_valid_STT (@MAHV VARCHAR(5), @MALOP_HOCVIEN VARCHAR(3))
RETURNs TINYINT
AS
BEGIN
    IF RIGHT(@MAHV, 2) BETWEEN 1 AND (SELECT SISO FROM LOP WHERE MALOP = @MALOP_HOCVIEN)
		RETURN 1
	RETURN 0
END
GO

ALTER TABLE HOCVIEN ADD CONSTRAINT CK_MAHV CHECK(
	LEN(MAHV) = 5 AND 
	dbo.check_valid_MALOP(MAHV) = 1 AND 
	dbo.check_valid_STT(MAHV, MALOP) = 1
)
GO

-- 3.	Thuộc tính GIOITINH chỉ có giá trị là “Nam” hoặc “Nu”.
ALTER TABLE HOCVIEN ADD CONSTRAINT CK_GIOITINH CHECK(GIOITINH IN ('Nam', 'Nu'))
GO

-- 4.	Điểm số của một lần thi có giá trị từ 0 đến 10 và cần lưu đến 2 số lẽ (VD: 6.22).
ALTER TABLE KETQUATHI ADD CONSTRAINT CK_DIEM CHECK(
	DIEM BETWEEN 0 AND 10 AND
	LEN(SUBSTRING(CAST(DIEM AS VARCHAR), CHARINDEX('.', DIEM) + 1, 1000)) >= 2
)
GO

-- 5.	Kết quả thi là “Dat” nếu điểm từ 5 đến 10  và “Khong dat” nếu điểm nhỏ hơn 5.
ALTER TABLE KETQUATHI ADD CONSTRAINT CK_KQUA CHECK(KQUA = IIF(DIEM BETWEEN 5 AND 10, 'Dat', 'Khong dat'))
GO

-- 6.	Học viên thi một môn tối đa 3 lần.
ALTER TABLE KETQUATHI ADD CONSTRAINT CK_SOLANTHI CHECK(LANTHI <= 3)
GO

-- 7.	Học kỳ chỉ có giá trị từ 1 đến 3.
ALTER TABLE GIANGDAY ADD CONSTRAINT CK_HOCKY CHECK(HOCKY BETWEEN 1 AND 3)
GO

-- 8.	Học vị của giáo viên chỉ có thể là “CN”, “KS”, “Ths”, ”TS”, ”PTS”.
ALTER TABLE GIAOVIEN ADD CONSTRAINT CK_HOCVI CHECK(HOCVI IN ('CN', 'KS', 'Ths', 'TS', 'PTS'))
GO

-- 11.	Học viên ít nhất là 18 tuổi.
ALTER TABLE HOCVIEN ADD CONSTRAINT CK_TUOI CHECK(GETDATE() - NGSINH >= 18)
GO

-- 12.	Giảng dạy một môn học ngày bắt đầu (TUNGAY) phải nhỏ hơn ngày kết thúc (DENNGAY).
ALTER TABLE GIANGDAY ADD CONSTRAINT CK_NGAY CHECK(TUNGAY < DENNGAY)
GO

-- 13.	Giáo viên khi vào làm ít nhất là 22 tuổi.
ALTER TABLE GIAOVIEN ADD CONSTRAINT CK_NGVL CHECK(GETDATE() - NGVL >= 22)
GO

-- 14.	Tất cả các môn học đều có số tín chỉ lý thuyết và tín chỉ thực hành chênh lệch nhau không quá 5.
ALTER TABLE MONHOC ADD CONSTRAINT CK_TC CHECK(ABS(TCLT - TCTH) <= 5)
GO

-- II.
-- Nhập dữu liệu khoa

INSERT INTO KHOA (MAKHOA, TENKHOA, NGTLAP, TRGKHOA)
VALUES
/*
('KHMT', 'Khoa hoc may tinh', '2005-06-07', 'GV01'),
('HTTT', 'He thong thong tin', '2005-06-07', 'GV02'),
('CNPM', 'Cong nghe phan mem', '2005-06-07', 'GV04'),
('MTT', 'Mang va truyen thong', '2005-10-20', 'GV03'),
('KTMT', 'Ky thuat may tinh', '2005-12-20',Null);
*/

('KHMT', 'Khoa hoc may tinh', '2005-06-07', Null),
('HTTT', 'He thong thong tin', '2005-06-07', Null),
('CNPM', 'Cong nghe phan mem', '2005-06-07', Null),
('MTT', 'Mang va truyen thong', '2005-10-20', Null),
('KTMT', 'Ky thuat may tinh', '2005-12-20', Null);
--SELECT * FROM KHOA 


-- Nhập dữ liệu môn học

INSERT INTO MONHOC(MAMH, TENMH, TCLT, TCTH, MAKHOA)
VALUES 
('THDC' ,'Tin hoc dai cuong' ,4, 1,'KHMT'),
('CTRR' ,'Cau truc roi rac' ,5, 0,'KHMT'),
('CSDL' ,'Co so du lieu' ,3, 1,'HTTT'),
('CTDLGT' ,'Cau truc du lieu va giai thuat' ,3, 1,'KHMT'),
('PTTKTT' ,'Phan tich thiet ke thuat toan' ,3, 0,'KHMT'),
('DHMT' ,'Do hoa may tinh' ,3, 1,'KHMT'),
('KTMT' ,'Kien truc may tinh' ,3, 0,'KTMT'),
('TKCSDL' ,'Thiet ke co so du lieu' ,3, 1,'HTTT'),
('PTTKHTTT' ,'Phan tich thiet ke he thong thong tin' ,4, 1,'HTTT'),
('HDH' ,'He dieu hanh' ,4, 0,'KTMT'),
('NMCNPM' ,'Nhap mon cong nghe phan mem' ,3, 0,'CNPM'),
('LTCFW' ,'Lap trinh C for win' ,3, 1,'CNPM'),
('LTHDT' ,'Lap trinh huong doi tuong' ,3, 1,'CNPM');
--SELECT * FROM MONHOC 

-- Nhập dữ liệu điều kiện

INSERT INTO DIEUKIEN (MAMH, MAMH_TRUOC)
VALUES 
      ('CSDL', 'CTRR'),
      ('CSDL', 'CTDLGT'),
      ('CTDLGT', 'THDC'),
      ('PTTKTT', 'THDC'),
      ('PTTKTT', 'CTDLGT'),
      ('DHMT', 'THDC'),
      ('LTHDT', 'THDC'),
      ('PTTKHTTT', 'CSDL');

--SELECT * FROM DIEUKIEN

-- Nhập dữ liệu giáo viên 

INSERT INTO GIAOVIEN(MAGV, HOTEN, HOCVI, HOCHAM, GIOITINH, NGSINH, NGVL, HESO, MUCLUONG, MAKHOA)
VALUES 
('GV01', 'Ho Thanh Son', 'PTS', 'GS', 'Nam', '1950-05-02' ,'2004-01-11' ,5.00, 2250000, 'KHMT'),
('GV02', 'Tran Tam Thanh', 'TS', 'PGS', 'Nam', '1965-12-17' ,'2004-04-20' ,4.50, 2025000, 'HTTT'),
('GV03', 'Do Nghiem Phung', 'TS', 'GS', 'Nu', '1950-08-01' ,'2004-09-23' ,4.00, 1800000, 'CNPM'),
('GV04', 'Tran Nam Son', 'TS', 'PGS', 'Nam', '1961-02-22' ,'2005-01-12' ,4.50, 2025000, 'KTMT'),
('GV05', 'Mai Thanh Danh', 'ThS', 'GV', 'Nam', '1958-03-12' ,'2005-01-12' ,3.00, 1350000, 'HTTT'),
('GV06', 'Tran Doan Hung', 'TS', 'GV', 'Nam', '1953-03-11' ,'2005-01-12' ,4.50, 2025000, 'KHMT'),
('GV07', 'Nguyen Minh Tien', 'ThS', 'GV', 'Nam', '1971-11-23' ,'2005-03-01' ,4.00, 1800000, 'KHMT'),
('GV08', 'Le Thi Tran', 'KS', Null, 'Nu', '1974-03-26' ,'2005-03-01' ,1.69, 760500, 'KHMT'),
('GV09', 'Nguyen To Lan', 'ThS', 'GV', 'Nu', '1966-12-31' ,'2005-03-01' ,4.00, 1800000, 'HTTT'),
('GV10', 'Le Tran Anh Loan', 'KS', Null, 'Nu', '1972-07-17' ,'2005-03-01' ,1.86, 837000, 'CNPM'),
('GV11', 'Ho Thanh Tung', 'CN', 'GV', 'Nam', '1980-01-12' ,'2005-05-15' ,2.67, 1201500, 'MTT'),
('GV12', 'Tran Van Anh', 'CN', Null, 'Nu', '1981-03-29' ,'2005-05-15' ,1.69, 760500, 'CNPM'),
('GV13', 'Nguyen Linh Dan', 'CN', Null, 'Nu', '1980-05-23' ,'2005-05-15' ,1.69, 760500, 'KTMT'),
('GV14', 'Truong Minh Chau', 'ThS', 'GV', 'Nu', '1976-11-30' ,'2005-05-15' ,3.00, 1350000, 'MTT'),
('GV15', 'Le Ha Thanh', 'ThS', 'GV', 'Nam', '1978-05-04' ,'2005-05-15' ,3.00, 1350000, 'KHMT');

--SELECT * FROM GIAOVIEN

-- Nhập dữ liệu Lớp

INSERT INTO LOP(MALOP, TENLOP, TRGLOP, SISO, MAGVCN)
VALUES 
('K11' ,'Lop 1 khoa 1', 'K1108' ,11, 'GV07'),
('K12' ,'Lop 2 khoa 1', 'K1205' ,12, 'GV09'),
('K13' ,'Lop 3 khoa 1', 'K1305' ,12, 'GV14');
--SELECT * FROM LOP

-- Nhập dữ liệu học viên

INSERT INTO HOCVIEN (MAHV, HO, TEN, NGSINH, GIOITINH, NOISINH, MALOP)
VALUES 
('K1101', 'Nguyen Van', 'A' ,'1986-01-27' ,'Nam' ,'TpHCM' ,'K11'),
('K1102', 'Tran Ngoc','Han' ,'1986-03-14' ,'Nu' ,'Kien Giang' ,'K11'),
('K1103', 'Ha Duy ','Lap' ,'1986-04-18' ,'Nam' ,'Nghe An' ,'K11'),
('K1104', 'Tran Ngoc','Linh' ,'1986-03-30' ,'Nu' ,'Tay Ninh' ,'K11'),
('K1105', 'Tran Minh','Long' ,'1986-02-27' ,'Nam' ,'TpHCM' ,'K11'),
('K1106', 'Le Nhat','Minh' ,'1986-01-24' ,'Nam' ,'TpHCM' ,'K11'),
('K1107', 'Nguyen Nhu','Nhut' ,'1986-01-27' ,'Nam' ,'Ha Noi' ,'K11'),
('K1108', 'Nguyen Manh','Tam' ,'1986-02-27' ,'Nam' ,'Kien Giang' ,'K11'),
('K1109', 'Phan Thi Thanh','Tam' ,'1986-01-27' ,'Nu' ,'Vinh Long' ,'K11'),
('K1110', 'Le Hoai','Thuong' ,'1986-02-05' ,'Nu' ,'Can Tho' ,'K11'),
('K1111', 'Le Ha','Vinh' ,'1986-12-25' ,'Nam' ,'Vinh Long' ,'K11'),
('K1201', 'Nguyen Van','B' ,'1986-02-11' ,'Nam' ,'TpHCM' ,'K12'),
('K1202', 'Nguyen Thi Kim','Duyen' ,'1986-01-18' ,'Nu' ,'TpHCM' ,'K12'),
('K1203', 'Tran Thi Kim','Duyen' ,'1986-09-17' ,'Nu' ,'TpHCM' ,'K12'),
('K1204', 'Truong My','Hanh' ,'1986-05-19' ,'Nu' ,'Dong Nai' ,'K12'),
('K1205', 'Nguyen Thanh','Nam' ,'1986-04-17' ,'Nam' ,'TpHCM' ,'K12'),
('K1206', 'Nguyen Thi Truc','Thanh' ,'1986-03-04' ,'Nu' ,'Kien Giang' ,'K12'),
('K1207', 'Tran Thi Bich','Thuy' ,'1986-02-08' ,'Nu' ,'Nghe An' ,'K12'),
('K1208', 'Huynh Thi Kim','Trieu' ,'1986-04-08' ,'Nu' ,'Tay Ninh' ,'K12'),
('K1209', 'Pham Thanh','Trieu' ,'1986-02-23' ,'Nam' ,'TpHCM' ,'K12'),
('K1210', 'Ngo Thanh','Tuan' ,'1986-02-14' ,'Nam' ,'TpHCM' ,'K12'),
('K1211', 'Do Thi','Xuan', '1986-03-09', 'Nu', 'Ha Noi' ,'K12'),
('K1212', 'Le Thi Phi','Yen' ,'1986-03-12' ,'Nu' ,'TpHCM' ,'K12'),
('K1301', 'Nguyen Thi Kim','Cuc' ,'1986-06-09' ,'Nu' ,'Kien Giang' ,'K13'),
('K1302', 'Truong Thi My','Hien' ,'1986-03-18' ,'Nu' ,'Nghe An' ,'K13'),
('K1303', 'Le Duc','Hien' ,'1986-03-21' ,'Nam' ,'Tay Ninh' ,'K13'),
('K1304', 'Le Quang','Hien' ,'1986-04-18' ,'Nam' ,'TpHCM' ,'K13'),
('K1305', 'Le Thi','Huong' ,'1986-03-27' ,'Nu' ,'TpHCM' ,'K13'),
('K1306', 'Nguyen Thai','Huu' ,'1986-03-30' ,'Nam' ,'Ha Noi' ,'K13'),
('K1307', 'Tran Minh','Man' ,'1986-05-28' ,'Nam' ,'TpHCM' ,'K13'),
('K1308', 'Nguyen Hieu','Nghia' ,'1986-04-08' ,'Nam' ,'Kien Giang' ,'K13'),
('K1309', 'Nguyen Trung','Nghia' ,'1987-01-18' ,'Nam' ,'Nghe An' ,'K13'),
('K1310', 'Tran Thi Hong','Tham' ,'1986-04-22' ,'Nu' ,'Tay Ninh' ,'K13'),
('K1311', 'Tran Minh','Thuc' ,'1986-04-04' ,'Nam' ,'TpHCM' ,'K13'),
('K1312', 'Nguyen Thi Kim','Yen' ,'1986-09-07' ,'Nu' ,'TpHCM' ,'K13');
--SELECT * FROM HOCVIEN

-- Nhập dữu liệu giảng dạy

INSERT INTO GIANGDAY (MALOP, MAMH, MAGV, HOCKY, NAM, TUNGAY, DENNGAY)
VALUES
('K11' ,'THDC' ,'GV07', 1 ,2006 ,'2006-01-02' ,'2006-05-12'),
('K12' ,'THDC' ,'GV06', 1 ,2006 ,'2006-01-02' ,'2006-05-12'),
('K13' ,'THDC' ,'GV15', 1 ,2006 ,'2006-01-02' ,'2006-05-12'),
('K11' ,'CTRR' ,'GV02', 1 ,2006 ,'2006-01-09' ,'2006-05-17'),
('K12' ,'CTRR' ,'GV02', 1 ,2006 ,'2006-01-09' ,'2006-05-17'),
('K13' ,'CTRR' ,'GV08', 1 ,2006 ,'2006-01-09' ,'2006-05-17'),
('K11' ,'CSDL' ,'GV05', 2 ,2006 ,'2006-06-01' ,'2006-07-15'),
('K12' ,'CSDL' ,'GV09', 2 ,2006 ,'2006-06-01' ,'2006-07-15'),
('K13' ,'CTDLGT' ,'GV15', 2 ,2006 ,'2006-06-01' ,'2006-07-15'),
('K13' ,'CSDL' ,'GV05', 3 ,2006 ,'2006-08-01' ,'2006-12-05'),
('K13' ,'DHMT' ,'GV07', 3 ,2006 ,'2006-08-01' ,'2006-12-05'),
('K11' ,'CTDLGT' ,'GV15', 3 ,2006 ,'2006-08-01' ,'2006-12-05'),
('K12' ,'CTDLGT' ,'GV15', 3 ,2006 ,'2006-08-01' ,'2006-12-05'),
('K11' ,'HDH' ,'GV04', 1 ,2007 ,'2007-01-02' ,'2007-02-18'),
('K12' ,'HDH' ,'GV04', 1 ,2007 ,'2007-01-02' ,'2007-03-20'),
('K11' ,'DHMT' ,'GV07', 1 ,2007 ,'2007-02-18' ,'2007-03-20');

-- SELECT * FROM GIANGDAY

-- Nhập dữ liệu kết quả thi
 
INSERT INTO KETQUATHI (MAHV, MAMH, LANTHI, NGTHI, DIEM, KQUA)
VALUES 
        ('K1101', 'CSDL' ,1, '2006-07-20', 10.00, 'Dat'),
        ('K1101', 'CTDLGT' ,1, '2006-12-28', 9.00, 'Dat'),
        ('K1101', 'THDC' ,1, '2006-05-20', 9.00, 'Dat'),
        ('K1101', 'CTRR' ,1, '2006-05-13', 9.50, 'Dat'),
        ('K1102', 'CSDL', 1, '2006-07-20', 4.00, 'Khong Dat'),
        ('K1102', 'CSDL', 2, '2006-07-27', 4.25, 'Khong Dat'),
        ('K1102', 'CSDL', 3, '2006-08-10', 4.50, 'Khong Dat'),
        ('K1102', 'CTDLGT', 1, '2006-12-28', 4.50, 'Khong Dat'),
        ('K1102', 'CTDLGT', 2, '2007-01-05', 4.00, 'Khong Dat'),
        ('K1102', 'CTDLGT' ,3, '2007-01-15', 6.00, 'Dat'),
        ('K1102', 'THDC' ,1, '2006-05-20', 5.00, 'Dat'),
        ('K1102', 'CTRR' ,1, '2006-05-13', 7.00, 'Dat'),
        ('K1103', 'CSDL', 1, '2006-07-20', 3.50, 'Khong Dat'),
        ('K1103', 'CSDL' ,2, '2006-07-27', 8.25, 'Dat'),
        ('K1103', 'CTDLGT', 1, '2006-12-28', 7.00, 'Dat'),
        ('K1103', 'THDC' ,1, '2006-05-20', 8.00, 'Dat'),
        ('K1103', 'CTRR' ,1, '2006-05-13', 6.50, 'Dat'),
        ('K1104', 'CSDL', 1, '2006-07-20', 3.75, 'Khong Dat'),
        ('K1104', 'CTDLGT', 1, '2006-12-28', 4.00, 'Khong Dat'),
        ('K1104', 'THDC', 1, '2006-05-20', 4.00, 'Khong Dat'),
        ('K1104', 'CTRR', 1, '2006-05-13', 4.00, 'Khong Dat'),
        ('K1104', 'CTRR', 2, '2006-05-20', 3.50, 'Khong Dat'),
        ('K1104', 'CTRR', 3, '2006-06-30', 4.00, 'Khong Dat'),
        ('K1201', 'CSDL' ,1, '2006-07-20', 6.00, 'Dat'),
        ('K1201', 'CTDLGT' ,1, '2006-12-28', 5.00, 'Dat'),
        ('K1201', 'THDC' ,1, '2006-05-20', 8.50, 'Dat'),
        ('K1201', 'CTRR' ,1, '2006-05-13', 9.00, 'Dat'),
        ('K1202', 'CSDL' ,1, '2006-07-20', 8.00, 'Dat'),
        ('K1202', 'CTDLGT' ,1, '2006-12-28', 4.00,'Khong Dat' ),
        ('K1202', 'CTDLGT' ,2, '2007-01-05', 5.00, 'Dat'),
        ('K1202', 'THDC', 1, '2006-05-20', 4.00, 'Khong Dat'),
        ('K1202', 'THDC', 2, '2006-05-27', 4.00, 'Khong Dat'),
        ('K1202', 'CTRR', 1, '2006-05-13', 3.00, 'Khong Dat'),
        ('K1202', 'CTRR', 2, '2006-05-20', 4.00, 'Khong Dat'),
        ('K1202', 'CTRR' ,3, '2006-06-30', 6.25, 'Dat'),
        ('K1203', 'CSDL' ,1, '2006-07-20', 9.25, 'Dat'),
        ('K1203', 'CTDLGT' ,1, '2006-12-28', 9.50, 'Dat'),
        ('K1203', 'THDC' ,1, '2006-05-20', 10.00, 'Dat'),
        ('K1203', 'CTRR' ,1, '2006-05-13', 10.00, 'Dat'),
        ('K1204', 'CSDL' ,1, '2006-07-20', 8.50, 'Dat'),
        ('K1204', 'CTDLGT' ,1, '2006-12-28', 6.75, 'Dat'),
        ('K1204', 'THDC', 1, '2006-05-20', 4.00, 'Khong Dat'),
        ('K1204', 'CTRR' ,1, '2006-05-13', 6.00, 'Dat'),
        ('K1301', 'CSDL', 1, '2006-12-20', 4.25, 'Khong Dat'),
        ('K1301', 'CTDLGT' ,1, '2006-07-25', 8.00, 'Dat'),
        ('K1301', 'THDC' ,1, '2006-05-20', 7.75, 'Dat'),
        ('K1301', 'CTRR' ,1, '2006-05-13', 8.00, 'Dat'),
        ('K1302', 'CSDL' ,1, '2006-12-20', 6.75, 'Dat'),
        ('K1302', 'CTDLGT' ,1, '2006-07-25', 5.00, 'Dat'),
        ('K1302', 'THDC' ,1, '2006-05-20', 8.00, 'Dat'),
        ('K1302', 'CTRR' ,1, '2006-05-13', 8.50, 'Dat'),
        ('K1303', 'CSDL', 1, '2006-12-20', 4.00, 'Khong Dat'),
        ('K1303', 'CTDLGT', 1, '2006-07-25', 4.50, 'Khong Dat'),
        ('K1303', 'CTDLGT', 2, '2006-08-07', 4.00, 'Khong Dat'),
        ('K1303', 'CTDLGT', 3, '2006-08-15', 4.25, 'Khong Dat'),
        ('K1303', 'THDC', 1, '2006-05-20', 4.50, 'Khong Dat'),
        ('K1303', 'CTRR', 1, '2006-05-13', 3.25, 'Khong Dat'),
        ('K1303', 'CTRR' ,2, '2006-05-20', 5.00, 'Dat'),
        ('K1304', 'CSDL' ,1, '2006-12-20', 7.75, 'Dat'),
        ('K1304', 'CTDLGT' ,1, '2006-07-25', 9.75, 'Dat'),
        ('K1304', 'THDC' ,1, '2006-05-20', 5.50, 'Dat'),
        ('K1304', 'CTRR' ,1, '2006-05-13', 5.00, 'Dat'),
        ('K1305', 'CSDL' ,1, '2006-12-20', 9.25, 'Dat'),
        ('K1305', 'CTDLGT' ,1, '2006-07-25', 10.00, 'Dat'),
        ('K1305', 'THDC' ,1, '2006-05-20', 8.00, 'Dat'),
        ('K1305', 'CTRR' ,1, '2006-05-13', 10.00, 'Dat');

 --SELECT * FROM KETQUATHI

 UPDATE KHOA SET TRGKHOA = 'GV01' Where MAKHOA = 'KHMT'
 Update KHOA set TRGKHOA = 'GV02' Where MAKHOA = 'HTTT'
 Update KHOA set TRGKHOA = 'GV03' Where MAKHOA = 'CNPM'
 Update KHOA set TRGKHOA = 'GV04' Where MAKHOA = 'MTT'
 GO
 ----------------------------------------------------LAB 3------------------------------------------------
-- II. Ngôn ngữ thao tác dữ liệu (Data Manipulation Language):
-- 1.	Tăng hệ số lương thêm 0.2 cho những giáo viên là trưởng khoa.
UPDATE GIAOVIEN 
SET HESO += HESO * 0.02 
WHERE MAGV IN (
	SELECT TRGKHOA FROM KHOA
)
GO
--SELECT * FROM GIAOVIEN

ALTER TABLE HOCVIEN ADD DIEMTB NUMERIC(4,2)
GO
--ALTER TABLE HOCVIEN DROP COLUMN DIEMTB
--GO
/* 2.	Cập nhật giá trị điểm trung bình tất cả các môn học (DIEMTB) của mỗi học viên 
(tất cả các môn học đều có hệ số 1 và nếu học viên thi một môn nhiều lần, chỉ lấy điểm của lần thi sau cùng). */
UPDATE HV SET DIEMTB = DTB_HOCVIEN.DTB
FROM HOCVIEN HV LEFT JOIN (
	SELECT MAHV, AVG(DIEM) AS DTB 
	FROM KETQUATHI A
	WHERE NOT EXISTS (
		SELECT 1 
		FROM KETQUATHI B 
		WHERE A.MAHV = B.MAHV AND A.MAMH = B.MAMH AND A.LANTHI < B.LANTHI
	) 
	GROUP BY MAHV
) DTB_HOCVIEN
ON HV.MAHV = DTB_HOCVIEN.MAHV
GO


ALTER TABLE HOCVIEN ADD GHICHU varchar(20)
GO
--ALTER TABLE HOCVIEN DROP COLUMN GHICHU
--GO
-- 3.	Cập nhật giá trị cho cột GHICHU là “Cam thi” đối với trường hợp: học viên có một môn bất kỳ thi lần thứ 3 dưới 5 điểm.
UPDATE HOCVIEN SET GHICHU = 'Cam thi'
WHERE MAHV IN (
	SELECT MAHV 
	FROM KETQUATHI 
	WHERE LANTHI = 3 AND DIEM < 5
)
GO

/* 4.	Cập nhật giá trị cho cột XEPLOAI trong quan hệ HOCVIEN như sau:
		o	Nếu DIEMTB  9 thì XEPLOAI =”XS”
		o	Nếu  8  DIEMTB < 9 thì XEPLOAI = “G”
		o	Nếu  6.5  DIEMTB < 8 thì XEPLOAI = “K”
		o	Nếu  5    DIEMTB < 6.5 thì XEPLOAI = “TB”
		o	Nếu  DIEMTB < 5 thì XEPLOAI = ”Y”
*/
ALTER TABLE HOCVIEN ADD XEPLOAI varchar(20)
GO
--ALTER TABLE HOCVIEN DROP COLUMN XEPLOAI
--GO

UPDATE HOCVIEN SET XEPLOAI = CASE 
	WHEN DIEMTB >= 9 THEN 'XS'
	WHEN DIEMTB >= 8 THEN 'G'
	WHEN DIEMTB >= 6.5 THEN 'K'
	WHEN DIEMTB >= 5 THEN 'TB'
	ELSE 'Y'
END
GO
SELECT * FROM HOCVIEN
GO

-- III. Ngôn ngữ truy vấn dữ liệu:
-- 6.	Tìm tên những môn học mà giáo viên có tên “Tran Tam Thanh” dạy trong học kỳ 1 năm 2006.
SELECT MAMH, TENMH FROM MONHOC
WHERE MAMH IN (
	SELECT DISTINCT MAMH 
	FROM GIANGDAY GD INNER JOIN GIAOVIEN GV 
	ON GD.MAGV = GV.MAGV 
	WHERE HOTEN = 'Tran Tam Thanh' AND HOCKY = 1 AND NAM = 2006
)
GO

-- 7.	Tìm những môn học (mã môn học, tên môn học) mà giáo viên chủ nhiệm lớp “K11” dạy trong học kỳ 1 năm 2006.
SELECT MAMH, TENMH FROM MONHOC
WHERE MAMH IN (
	SELECT DISTINCT MAMH FROM GIANGDAY WHERE MAGV IN (
		SELECT MAGVCN FROM LOP WHERE MALOP = 'K11'
	) AND HOCKY = 1 AND NAM = 2006
)
GO

-- 8.	Tìm họ tên lớp trưởng của các lớp mà giáo viên có tên “Nguyen To Lan” dạy môn “Co So Du Lieu”.
SELECT HO + ' ' + TEN AS HOTEN FROM HOCVIEN
WHERE MAHV IN (
	SELECT TRGLOP FROM LOP 
	WHERE MALOP IN (
		SELECT DISTINCT MALOP FROM GIANGDAY 
		WHERE MAGV IN (
			SELECT MAGV FROM GIAOVIEN WHERE HOTEN = 'Nguyen To Lan'
		) AND MAMH IN (
			SELECT MAMH FROM MONHOC WHERE TENMH = 'Co So Du Lieu'
		)
	)
)
GO

-- 9.	In ra danh sách những môn học (mã môn học, tên môn học) phải học liền trước môn “Co So Du Lieu”.
SELECT MAMH, TENMH FROM MONHOC
WHERE MAMH IN (
	SELECT MAMH_TRUOC FROM DIEUKIEN WHERE MAMH IN (
		SELECT MAMH FROM MONHOC WHERE TENMH = 'Co So Du Lieu'
	)
)
GO

-- 10.	Môn “Cau Truc Roi Rac” là môn bắt buộc phải học liền trước những môn học (mã môn học, tên môn học) nào.
SELECT MAMH, TENMH FROM MONHOC
WHERE MAMH IN (
	SELECT MAMH FROM DIEUKIEN WHERE MAMH_TRUOC IN (
		SELECT MAMH FROM MONHOC WHERE TENMH = 'Cau Truc Roi Rac'
	)
)
GO

-- 11.	Tìm họ tên giáo viên dạy môn CTRR cho cả hai lớp “K11” và “K12” trong cùng học kỳ 1 năm 2006.
SELECT HOTEN FROM GIAOVIEN 
WHERE MAGV IN (
	SELECT MAGV FROM GIANGDAY 
	WHERE MAMH = 'CTRR' AND MALOP IN ('K11', 'K12') AND HOCKY = 1 AND NAM = 2006
	GROUP BY MAGV 
	HAVING COUNT(DISTINCT MALOP) = 2
)
GO

-- 12.	Tìm những học viên (mã học viên, họ tên) thi không đạt môn CSDL ở lần thi thứ 1 nhưng chưa thi lại môn này.
SELECT MAHV, HO + ' ' + TEN AS HOTEN FROM HOCVIEN 
WHERE MAHV IN (
	SELECT MAHV FROM KETQUATHI A
	WHERE NOT EXISTS (
		SELECT 1 FROM KETQUATHI B 
		WHERE A.MAHV = B.MAHV AND A.MAMH = B.MAMH AND A.LANTHI < B.LANTHI
	) AND MAMH = 'CSDL' AND LANTHI = 1 AND KQUA = 'Khong Dat'
)
GO

-- 13.	Tìm giáo viên (mã giáo viên, họ tên) không được phân công giảng dạy bất kỳ môn học nào.
SELECT MAGV, HOTEN FROM GIAOVIEN 
WHERE MAGV NOT IN (
	SELECT DISTINCT MAGV FROM GIANGDAY
)
GO

-- 14.	Tìm giáo viên (mã giáo viên, họ tên) không được phân công giảng dạy bất kỳ môn học nào thuộc khoa giáo viên đó phụ trách.
SELECT MAGV, HOTEN FROM GIAOVIEN 
WHERE MAGV NOT IN (
	SELECT GD.MAGV
	FROM GIANGDAY GD INNER JOIN GIAOVIEN GV 
	ON GD.MAGV = GV.MAGV INNER JOIN MONHOC MH
	ON GD.MAMH = MH.MAMH
	WHERE GV.MAKHOA = MH.MAKHOA
)
GO

-- 15.	Tìm họ tên các học viên thuộc lớp “K11” thi một môn bất kỳ quá 3 lần vẫn “Khong dat” hoặc thi lần thứ 2 môn CTRR được 5 điểm.
SELECT HO + ' ' + TEN AS HOTEN FROM HOCVIEN
WHERE MAHV IN (
	SELECT MAHV FROM KETQUATHI A
	WHERE LEFT(MAHV, 3) = 'K11' AND ((
		NOT EXISTS (
			SELECT 1 FROM KETQUATHI B 
			WHERE A.MAHV = B.MAHV AND A.MAMH = B.MAMH AND A.LANTHI < B.LANTHI
		)  AND LANTHI = 3 AND KQUA = 'Khong Dat'
	) OR MAMH = 'CTRR' AND LANTHI = 2 AND DIEM = 5)
)
GO

-- 16.	Tìm họ tên giáo viên dạy môn CTRR cho ít nhất hai lớp trong cùng một học kỳ của một năm học.
SELECT HOTEN FROM GIAOVIEN 
WHERE MAGV IN (
	SELECT MAGV FROM GIANGDAY 
	WHERE MAMH = 'CTRR'
	GROUP BY MAGV, HOCKY, NAM 
	HAVING COUNT(MALOP) >= 2
)
GO

-- 17.	Danh sách học viên và điểm thi môn CSDL (chỉ lấy điểm của lần thi sau cùng).
SELECT HV.MAHV, HO + ' ' + TEN AS HOTEN, DIEM 
FROM HOCVIEN HV INNER JOIN (
	SELECT MAHV, DIEM 
	FROM KETQUATHI A
	WHERE NOT EXISTS (
		SELECT 1 
		FROM KETQUATHI B 
		WHERE A.MAHV = B.MAHV AND A.MAMH = B.MAMH AND A.LANTHI < B.LANTHI
	) AND MAMH = 'CSDL'
) DIEM_CSDL
ON HV.MAHV = DIEM_CSDL.MAHV
GO

-- 18.	Danh sách học viên và điểm thi môn “Co So Du Lieu” (chỉ lấy điểm cao nhất của các lần thi).
SELECT HV.MAHV, HO + ' ' + TEN AS HOTEN, DIEM 
FROM HOCVIEN HV INNER JOIN (
	SELECT MAHV, MAX(DIEM) AS DIEM FROM KETQUATHI 
	WHERE MAMH IN (
		SELECT MAMH FROM MONHOC 
		WHERE TENMH = 'Co So Du Lieu'
	) 
	GROUP BY MAHV, MAMH
) DIEM_CSDL_MAX
ON HV.MAHV = DIEM_CSDL_MAX.MAHV
GO
-- III. Ngôn ngữ truy vấn dữ liệu:
-- 1.	In ra danh sách (mã học viên, họ tên, ngày sinh, mã lớp) lớp trưởng của các lớp.
SELECT HV.MAHV, HO + ' ' + TEN AS HOTEN, NGSINH, HV.MALOP 
FROM HOCVIEN HV INNER JOIN LOP 
ON HV.MAHV = LOP.TRGLOP
GO

-- 2.	In ra bảng điểm khi thi (mã học viên, họ tên , lần thi, điểm số) môn CTRR của lớp “K12”, sắp xếp theo tên, họ học viên.
SELECT KQ.MAHV, HO + ' ' + TEN AS HOTEN, LANTHI, DIEM 
FROM KETQUATHI KQ INNER JOIN HOCVIEN HV 
ON KQ.MAHV = HV.MAHV
WHERE LEFT(KQ.MAHV, 3) = 'K12' AND MAMH = 'CTRR'
ORDER BY TEN, HO
GO

-- 3.	In ra danh sách những học viên (mã học viên, họ tên) và những môn học mà học viên đó thi lần thứ nhất đã đạt.
SELECT KQ.MAHV, HO + ' ' + TEN AS HOTEN, MAMH
FROM KETQUATHI KQ INNER JOIN HOCVIEN HV 
ON KQ.MAHV = HV.MAHV
GROUP BY KQ.MAHV, HO, TEN, MAMH, KQUA
HAVING MAX(LANTHI) = 1 AND KQUA ='DAT'
ORDER BY KQ.MAHV
GO

-- 4.	In ra danh sách học viên (mã học viên, họ tên) của lớp “K11” thi môn CTRR không đạt (ở lần thi 1).
SELECT KQ.MAHV, HO + ' ' + TEN AS HOTEN
FROM KETQUATHI KQ INNER JOIN HOCVIEN HV 
ON KQ.MAHV = HV.MAHV
WHERE LEFT(KQ.MAHV, 3) = 'K11' AND MAMH = 'CTRR' AND LANTHI = 1 AND KQUA = 'Khong Dat'
GO

-- 5.	* Danh sách học viên (mã học viên, họ tên) của lớp “K” thi môn CTRR không đạt (ở tất cả các lần thi).
SELECT A.MAHV, HOTEN FROM (
	SELECT KQ.MAHV, HO + ' ' + TEN AS HOTEN, LANTHI
	FROM KETQUATHI KQ INNER JOIN HOCVIEN HV 
	ON KQ.MAHV = HV.MAHV
	WHERE LEFT(KQ.MAHV, 3) = 'K11' AND MAMH = 'CTRR' AND KQUA = 'Khong Dat'
) A 
INNER JOIN (
	SELECT MAHV, MAX(LANTHI) LANTHIMAX FROM KETQUATHI 
	WHERE LEFT(MAHV, 3) = 'K11' AND MAMH = 'CTRR'
	GROUP BY MAHV, MAMH 
) B 
ON A.MAHV = B.MAHV
WHERE LANTHI = LANTHIMAX
GO
---------------------------------LAB 4-----------------------------------
-- 19.	Khoa nào (mã khoa, tên khoa) được thành lập sớm nhất.
SELECT MAKHOA, TENKHOA FROM (
	SELECT MAKHOA, TENKHOA, RANK() OVER (ORDER BY NGTLAP) RANK_NGTLAP FROM KHOA 
) A
WHERE RANK_NGTLAP = 1
GO

-- 20.	Có bao nhiêu giáo viên có học hàm là “GS” hoặc “PGS”.
SELECT HOCHAM, COUNT(HOCHAM) SL FROM GIAOVIEN 
WHERE HOCHAM IN ('GS', 'PGS') 
GROUP BY HOCHAM
GO

-- 21.	Thống kê có bao nhiêu giáo viên có học vị là “CN”, “KS”, “Ths”, “TS”, “PTS” trong mỗi khoa.
SELECT MAKHOA, HOCVI, COUNT(HOCVI) SL FROM GIAOVIEN 
GROUP BY MAKHOA, HOCVI
ORDER BY MAKHOA
GO

-- 22.	Mỗi môn học thống kê số lượng học viên theo kết quả (đạt và không đạt).
SELECT MAMH, KQUA, COUNT(MAHV) SL
FROM KETQUATHI A
WHERE NOT EXISTS (
	SELECT 1 
	FROM KETQUATHI B 
	WHERE A.MAHV = B.MAHV AND A.MAMH = B.MAMH AND A.LANTHI < B.LANTHI
)
GROUP BY MAMH, KQUA
GO

-- 23.	Tìm giáo viên (mã giáo viên, họ tên) là giáo viên chủ nhiệm của một lớp, đồng thời dạy cho lớp đó ít nhất một môn học.
SELECT MAGV, HOTEN 
FROM GIAOVIEN 
WHERE MAGV IN(
	SELECT DISTINCT MAGV
	FROM GIANGDAY GD INNER JOIN LOP
	ON GD.MALOP = LOP.MALOP
	WHERE MAGV = MAGVCN 
)
GO

-- 24.	Tìm họ tên lớp trưởng của lớp có sỉ số cao nhất.

SELECT HO + ' ' + TEN HOTEN FROM LOP INNER JOIN HOCVIEN HV
ON LOP.TRGLOP = HV.MAHV
WHERE SISO = (
	SELECT MAX(SISO) FROM LOP
)
GO

-- 25.	* Tìm họ tên những LOPTRG thi không đạt quá 3 môn (mỗi môn đều thi không đạt ở tất cả các lần thi).
SELECT HO + ' ' + TEN HOTEN FROM HOCVIEN
WHERE MAHV IN (
	SELECT MAHV FROM KETQUATHI A
	WHERE MAHV IN (
		SELECT TRGLOP FROM LOP
	) AND NOT EXISTS (
		SELECT 1 FROM KETQUATHI B 
		WHERE A.MAHV = B.MAHV AND A.MAMH = B.MAMH AND A.LANTHI < B.LANTHI
	) AND KQUA = 'Khong Dat'
	GROUP BY MAHV
	HAVING COUNT(MAMH) >= 3
)
GO

-- 26.	Tìm học viên (mã học viên, họ tên) có số môn đạt điểm 9,10 nhiều nhất.
SELECT A.MAHV, HO + ' ' + TEN HOTEN FROM (
	SELECT MAHV, RANK () OVER (ORDER BY COUNT(MAMH) DESC) RANK_MH FROM KETQUATHI KQ 
	WHERE DIEM BETWEEN 9 AND 10
	GROUP BY KQ.MAHV
) A INNER JOIN HOCVIEN HV
ON A.MAHV = HV.MAHV
WHERE RANK_MH = 1

GO

-- 27.	Trong từng lớp, tìm học viên (mã học viên, họ tên) có số môn đạt điểm 9,10 nhiều nhất.
SELECT LEFT(A.MAHV, 3) MALOP, A.MAHV, HO + ' ' + TEN HOTEN FROM (
	SELECT MAHV, RANK () OVER (ORDER BY COUNT(MAMH) DESC) RANK_MH FROM KETQUATHI KQ 
	WHERE DIEM BETWEEN 9 AND 10
	GROUP BY KQ.MAHV
) A INNER JOIN HOCVIEN HV
ON A.MAHV = HV.MAHV
WHERE RANK_MH = 1
GROUP BY LEFT(A.MAHV, 3), A.MAHV, HO, TEN
GO

-- 28.	Trong từng học kỳ của từng năm, mỗi giáo viên phân công dạy bao nhiêu môn học, bao nhiêu lớp.
SELECT HOCKY, NAM, MAGV, COUNT(MAMH) SOMH, COUNT(MALOP) SOLOP FROM GIANGDAY
GROUP BY HOCKY, NAM, MAGV
GO

-- 29.	Trong từng học kỳ của từng năm, tìm giáo viên (mã giáo viên, họ tên) giảng dạy nhiều nhất.
SELECT HOCKY, NAM, A.MAGV, HOTEN FROM (
	SELECT HOCKY, NAM, MAGV, RANK() OVER (PARTITION BY HOCKY, NAM ORDER BY COUNT(MAMH) DESC) RANK_SOMH FROM GIANGDAY
	GROUP BY HOCKY, NAM, MAGV
) A INNER JOIN GIAOVIEN GV 
ON A.MAGV = GV.MAGV
WHERE RANK_SOMH = 1
GO

-- 30.	Tìm môn học (mã môn học, tên môn học) có nhiều học viên thi không đạt (ở lần thi thứ 1) nhất.
SELECT A.MAMH, TENMH FROM (
	SELECT MAMH, RANK() OVER (ORDER BY COUNT(MAHV) DESC) RANK_SOHV FROM KETQUATHI
	WHERE LANTHI = 1 AND KQUA = 'Khong Dat'
	GROUP BY MAMH
) A INNER JOIN MONHOC MH
ON A.MAMH = MH.MAMH
WHERE RANK_SOHV = 1
GO

-- 31.	Tìm học viên (mã học viên, họ tên) thi môn nào cũng đạt (chỉ xét lần thi thứ 1).
SELECT A.MAHV, HO + ' ' + TEN HOTEN FROM (
	SELECT MAHV, COUNT(KQUA) SODAT FROM KETQUATHI 
	WHERE LANTHI = 1 AND KQUA = 'Dat'
	GROUP BY MAHV
	INTERSECT
	SELECT MAHV, COUNT(MAMH) SOMH FROM KETQUATHI 
	WHERE LANTHI = 1
	GROUP BY MAHV
) A INNER JOIN HOCVIEN HV
ON A.MAHV = HV.MAHV

-- 32.	* Tìm học viên (mã học viên, họ tên) thi môn nào cũng đạt (chỉ xét lần thi sau cùng).
SELECT C.MAHV, HO + ' ' + TEN HOTEN FROM (
	SELECT MAHV, COUNT(KQUA) SODAT FROM KETQUATHI A
	WHERE NOT EXISTS (
		SELECT 1 
		FROM KETQUATHI B 
		WHERE A.MAHV = B.MAHV AND A.MAMH = B.MAMH AND A.LANTHI < B.LANTHI
	) AND KQUA = 'Dat'
	GROUP BY MAHV
	INTERSECT
	SELECT MAHV, COUNT(MAMH) SOMH FROM KETQUATHI 
	WHERE LANTHI = 1
	GROUP BY MAHV
) C INNER JOIN HOCVIEN HV
ON C.MAHV = HV.MAHV
GO

-- 33.	* Tìm học viên (mã học viên, họ tên) đã thi tất cả các môn đều đạt (chỉ xét lần thi thứ 1).
SELECT A.MAHV, HO + ' ' + TEN HOTEN FROM (
	SELECT MAHV, COUNT(KQUA) SODAT FROM KETQUATHI 
	WHERE LANTHI = 1 AND KQUA = 'Dat'
	GROUP BY MAHV
	INTERSECT
	SELECT MAHV, COUNT(MAMH) SOMH FROM KETQUATHI 
	WHERE LANTHI = 1
	GROUP BY MAHV
) A INNER JOIN HOCVIEN HV
ON A.MAHV = HV.MAHV
GO

-- 34.	* Tìm học viên (mã học viên, họ tên) đã thi tất cả các môn đều đạt  (chỉ xét lần thi sau cùng).
SELECT C.MAHV, HO + ' ' + TEN HOTEN FROM (
	SELECT MAHV, COUNT(KQUA) SODAT FROM KETQUATHI A
	WHERE NOT EXISTS (
		SELECT 1 FROM KETQUATHI B 
		WHERE A.MAHV = B.MAHV AND A.MAMH = B.MAMH AND A.LANTHI < B.LANTHI
	) AND KQUA = 'Dat'
	GROUP BY MAHV
	INTERSECT
	SELECT MAHV, COUNT(MAMH) SOMH FROM KETQUATHI 
	WHERE LANTHI = 1
	GROUP BY MAHV
) C INNER JOIN HOCVIEN HV
ON C.MAHV = HV.MAHV
GO

-- 35.	** Tìm học viên (mã học viên, họ tên) có điểm thi cao nhất trong từng môn (lấy điểm ở lần thi sau cùng).
SELECT A.MAHV, HO + ' ' + TEN HOTEN FROM (
	SELECT B.MAMH, MAHV, DIEM, DIEMMAX
	FROM KETQUATHI B INNER JOIN (
		SELECT MAMH, MAX(DIEM) DIEMMAX FROM KETQUATHI
		GROUP BY MAMH
	) C 
	ON B.MAMH = C.MAMH
	WHERE NOT EXISTS (
		SELECT 1 FROM KETQUATHI D 
		WHERE B.MAHV = D.MAHV AND B.MAMH = D.MAMH AND B.LANTHI < D.LANTHI
	) AND DIEM = DIEMMAX
) A INNER JOIN HOCVIEN HV
ON A.MAHV = HV.MAHV
GO

-----------------------------------------------LAB 5--------------------------------------

-- I. Ngôn ngữ định nghĩa dữ liệu (Data Definition Language):
-- 9.	Lớp trưởng của một lớp phải là học viên của lớp đó.
CREATE TRIGGER trg_ins_udt_LopTruong ON LOP
FOR INSERT, UPDATE
AS
BEGIN
	IF NOT EXISTS (SELECT * FROM INSERTED I, HOCVIEN HV
	WHERE I.TRGLOP = HV.MAHV AND I.MALOP = HV.MALOP)
	BEGIN
		PRINT 'Error: Lop truong cua mot lop phai la hoc vien cua lop do'
		ROLLBACK TRANSACTION
	END
END
Go
CREATE TRIGGER trg_del_HOCVIEN ON HOCVIEN
FOR DELETE
AS
BEGIN
	IF EXISTS (SELECT * FROM DELETED D, INSERTED I, LOP L 
	WHERE D.MAHV = L.TRGLOP AND D.MALOP = L.MALOP)
	BEGIN
		PRINT 'Error: Hoc vien hien tai dang la truong lop'
		ROLLBACK TRANSACTION
	END
END

-- UPDATE LOP SET TRGLOP = 'K1205' Where MALOP = 'K11'
-- UPDATE LOP SET TRGLOP = 'K1105' Where MALOP = 'K11'
SELECT * FROM LOP
GO

-- 10.	Trưởng khoa phải là giáo viên thuộc khoa và có học vị “TS” hoặc “PTS”.
-- Trigger len KHOA
CREATE TRIGGER trg_ins_TruongKhoa ON KHOA
FOR INSERT, UPDATE
AS
BEGIN
	IF NOT EXISTS (SELECT * FROM INSERTED I, GIAOVIEN GV
	WHERE I.TRGKHOA = GV.MAGV AND I.MAKHOA = GV.MAKHOA)
	BEGIN
		PRINT 'Error: Truong khoa phai la mot giao vien thuoc khoa do'
		ROLLBACK TRANSACTION
	END
END
GO
CREATE TRIGGER trg_ins_Hocvi_TruongKhoa ON KHOA
FOR INSERT, UPDATE
AS
BEGIN
	IF NOT EXISTS (SELECT * FROM INSERTED I, GIAOVIEN GV
	WHERE I.TRGKHOA = GV.MAGV AND (GV.HOCVI = 'TS' OR GV.HOCVI = 'PTS'))
	BEGIN
		PRINT 'Error: Truong khoa phai la mot giao vien co hoc vi la PTS hay TS'
		ROLLBACK TRANSACTION
	End
ENd
-- UPDATE KHOA SET TRGKHOA = 'GV01' Where MAKHOA = 'KHMT'
GO

--Trigger len GIAOVIEN
CREATE TRIGGER trg_ins_TruongKhoa_gv ON GIAOVIEN
FOR INSERT, UPDATE
AS
BEGIN
	IF NOT EXISTS (SELECT * FROM INSERTED I, KHOA K
	WHERE I.MAGV = K.TRGKHOA AND I.MAKHOA = K.MAKHOA)
	BEGIN
		PRINT 'Error: Truong khoa phai la mot giao vien thuoc khoa do'
		ROLLBACK TRANSACTION
	END
END
GO
CREATE TRIGGER trg_ins_Hocvi_TruongKhoa_gv ON GIAOVIEN
FOR INSERT, UPDATE
AS
BEGIN
	IF NOT EXISTS (SELECT * FROM INSERTED I, KHOA K
	WHERE I.MAGV = K.TRGKHOA AND (I.HOCVI = 'TS' OR I.HOCVI = 'PTS'))
	BEGIN
		PRINT 'Error: Truong khoa phai la mot giao vien co hoc vi la PTS hay TS'
		ROLLBACK TRANSACTION
	End
ENd
GO
-- UPDATE GIAOVIEN SET HOCVI = 'CN' WHERE MAGV = 'GV01'

-- 15.	Học viên chỉ được thi một môn học nào đó khi lớp của học viên đã học xong môn học này.
-- Trigger len KETQUATHI
CREATE TRIGGER trg_ins_ketqua ON KETQUATHI
FOR INSERT, UPDATE
AS 
BEGIN
	IF NOT EXISTS (SELECT * FROM INSERTED I, HOCVIEN HV, GIANGDAY GD
	WHERE I.MAHV = HV.MAHV AND HV.MALOP = GD.MALOP AND I.MAMH = GD.MAMH AND I.NGTHI > GD.DENNGAY)
	BEGIN
		Print 'Error: Hoc vien phai hoc xong mon hoc de duoc thi'
		ROLLBACK TRANSACTION
	END
END

--INSERT INTO KETQUATHI (MAHV, MAMH, LANTHI, NGTHI, DIEM, KQUA)
--VALUES 
        
--		('K1211', 'CSDL' ,1, '2006/20/05', 10.00, 'Dat');
GO
-- Trigger len GIANGDAY
CREATE TRIGGER trg_ins_ketqua_GD ON GIANGDAY
FOR INSERT, UPDATE
AS
BEGIN 
	IF NOT EXISTS (SELECT * FROM INSERTED I, HOCVIEN HV, KETQUATHI KQ
	WHERE I.MALOP = HV.MALOP AND HV.MAHV = KQ.MAHV AND I.MAMH = KQ.MAMH AND I.DENNGAY < KQ.NGTHI)
	BEGIN
		PRINT 'Error: Ngay ket thuc lop phai som hon ngay thi mon hoc'
		ROLLBACK TRANSACTION
	END
END
GO

--UPDATE GIANGDAY SET DENNGAY = '2006-21-03' Where MALOP = 'K11'AND MAMH = 'THDC'
--GO


-- 16.	Mỗi học kỳ của một năm học, một lớp chỉ được học tối đa 3 môn.
CREATE TRIGGER trg_ins_maxmonhoc ON GIANGDAY
FOR INSERT, UPDATE
AS
BEGIN 
	DECLARE @SL_Mon INT
	SELECT @SL_Mon = COUNT(GD.MAMH) FROM INSERTED I, GIANGDAY GD
	WHERE I.MALOP = GD.MALOP AND I.HOCKY = GD.HOCKY AND I.NAM = GD.NAM
	IF(@SL_Mon = 4)
	BEGIN
		PRINT 'Error: Lop nay da hoc qua 3 mon mot hoc ky'
		ROLLBACK TRANSACTION
	END
END
GO

--UPDATE GIANGDAY SET HOCKY = '1' WHERE MALOP = 'K11' AND MAMH = 'CTDLGT'
--UPDATE GIANGDAY SET HOCKY = '1' WHERE MALOP = 'K11' AND MAMH = 'CSDL'
--SELECT * FROM GIANGDAY

-- 17.	Sỉ số của một lớp bằng với số lượng học viên thuộc lớp đó.

--------------
CREATE TRIGGER INSERT_HOCVIEN
ON HOCVIEN
FOR INSERT
AS
		UPDATE LOP
		SET SISO=SISO+1
		WHERE MALOP=(SELECT MALOP
		FROM INSERTED)
GO
------------
Create TRIGGER DELETE_HOCVIEN
ON HOCVIEN
FOR DELETE
AS
		
	Declare @MALOP CHAR(3)
	SELECT @MALOP=D.MALOP
	FROM DELETED D, LOP L
	WHERE D.MALOP=L.MALOP
	UPDATE LOP
	SET SISO=SISO-1
	WHERE MALOP=@MALOP
GO
-------------
CREATE TRIGGER UPDATE_HOCVIEN
ON HOCVIEN
FOR UPDATE
AS
	UPDATE LOP SET SISO=SISO+1
	WHERE MALOP=(SELECT MALOP
	FROM INSERTED)
UPDATE LOP
SET SISO=SISO-1
WHERE MALOP=(SELECT MALOP
 FROM DELETED)
	-------------------------

/*INSERT INTO HOCVIEN(MAHV, HO, TEN, NGSINH, GIOITINH, NOISINH, MALOP)
	VALUES ('K1112', 'Nguyen Xuan', 'Duy' ,'1986-01-27' ,'Nam' ,'TpHCM' ,'K11');
DELETE HOCVIEN WHERE MAHV = 'K1112'
Update HOCVIEN SET MALOP = 'K12' WHERE MAHV = 'K1112'
SELECT * FROM LOP
SELECT * FROM HOCVIEN*/

GO

/* 18.	Trong quan hệ DIEUKIEN giá trị của thuộc tính MAMH và MAMH_TRUOC trong cùng một bộ 
không được giống nhau (“A”,”A”) và cũng không tồn tại hai bộ (“A”,”B”) và (“B”,”A”). */
CREATE Trigger trg_ins_update ON DIEUKIEN
FOR INSERT, UPDATE
AS
	Declare @MAMH varchar(10), @MAMH_TRUOC varchar(10)
	SELECT @MAMH = I.MAMH, @MAMH_TRUOC = I.MAMH_TRUOC FROM INSERTED I
	IF((@MAMH = @MAMH_TRUOC) OR 
		(@MAMH IN (SELECT DK.MAMH_TRUOC FROM DIEUKIEN DK WHERE DK.MAMH = @MAMH_TRUOC)) OR
		(@MAMH_TRUOC IN (SELECT DK.MAMH FROM DIEUKIEN DK WHERE DK.MAMH_TRUOC = @MAMH)))
	Begin
		Print 'Dieu kien khong hop le'
		Rollback Transaction
	ENd
GO

--INSERT INTO DIEUKIEN(MAMH, MAMH_TRUOC)
--VALUES ('CTRR', 'CSDL')

-- 19.	Các giáo viên có cùng học vị, học hàm, hệ số lương thì mức lương bằng nhau.
Create trigger trg_updt_luonggv ON GIAOVIEN
FOR INSERT, UPDATE
AS
	Declare @LUONG money, @MAGV char(4)
	SELECT DISTINCT @LUONG = GV.MUCLUONG, @MAGV = I.MAGV FROM GIAOVIEN GV, INSERTED I
	WHERE GV.HOCHAM = I.HOCHAM AND GV.HOCVI = I.HOCVI AND GV.HESO = I.HESO AND GV.MAGV <> I.MAGV
	UPDATE GIAOVIEN SET MUCLUONG = @LUONG WHERE  MAGV = @MAGV
GO
/*
INSERT INTO GIAOVIEN(MAGV, HOTEN, HOCVI, HOCHAM, GIOITINH, NGSINH, NGVL, HESO, MUCLUONG, MAKHOA)
VALUES 
('GV16', 'Phan Tuan Anh Khoa', 'PTS', 'GS', 'Nam', '1950-05-02' ,'2004-01-11' ,5.00, 2350000, 'CNPM');
SELECT * FROm GIAOVIEN
*/
-- 20.	Học viên chỉ được thi lại (lần thi >1) khi điểm của lần thi trước đó dưới 5.
create Trigger trg_ins_updt_thilai ON KETQUATHI
FOR INSERT, UPDATE
AS
	DECLARE @LANTHI INT, @DIEM NUMERIC(4,2)
	SELECT @LANTHI = I.LANTHI FROM INSERTED I
	IF(@LANTHI > 1)
		BEGIN
			SELECT @DIEM = KQ.DIEM FROM INSERTED I, KETQUATHI KQ
			WHERE I.MAHV = KQ.MAHV AND I.MAMH = KQ.MAMH AND KQ.LANTHI = @LANTHI - 1
			IF(@DIEM >= 5)
				BEGIN 
					PRINT 'Hoc vien da thi dat mon nay'
					ROLLBACK TRANSACTION
				END
		END
	DELETE FROM KETQUATHI
	WHERE LANTHI > @LANTHI
GO

--INSERT INTO KETQUATHI (MAHV, MAMH, LANTHI, NGTHI, DIEM, KQUA)
--VALUES 
 --       ('K1101', 'CSDL' ,2, '2006-07-20', 9.00, 'Dat');

-- 21.	Ngày thi của lần thi sau phải lớn hơn ngày thi của lần thi trước (cùng học viên, cùng môn học).
create TRIGGER trg_ins_ngaythi ON KETQUATHI
FOR INSERT, UPDATE
AS 
	DECLARE @NGAYTHI SMALLDATETIME, @LANTHI INT, @NGAYTHISAU smalldatetime, @LANTHISAU INT
	SELECT @LANTHI = KQ.LANTHI, @LANTHISAU = I.LANTHI, @NGAYTHI = KQ.NGTHI, @NGAYTHISAU = I.NGTHI FROM INSERTED I, HOCVIEN HV, KETQUATHI KQ
	WHERE I.MAHV = HV.MAHV AND I.MAMH = KQ.MAMH
	IF(@LANTHI < @LANTHISAU)
		BEGIN
			IF(@NGAYTHI > @NGAYTHISAU)
			BEGIN	
				PRINT 'Ngay thi khong hop le'
				Rollback Transaction
			END
		END
	Else
		PRINT 'Hoc vien da thi lan nay roi'
GO
/*
INSERT INTO KETQUATHI (MAHV, MAMH, LANTHI, NGTHI, DIEM, KQUA)
VALUES 
        ('K1104', 'CSDL' ,2, '2006-06-20', 9.00, 'Dat');
SELECT * FROM KETQUATHI
*/
-- 22.	Học viên chỉ được thi những môn mà lớp của học viên đó đã học xong.
CREATE TRIGGER trg_ins_ketqua_22 ON KETQUATHI
FOR INSERT, UPDATE
AS 
BEGIN
	IF NOT EXISTS (SELECT * FROM INSERTED I, HOCVIEN HV, GIANGDAY GD
	WHERE I.MAHV = HV.MAHV AND HV.MALOP = GD.MALOP AND I.MAMH = GD.MAMH AND I.NGTHI > GD.DENNGAY)
	BEGIN
		Print 'Error: Hoc vien phai hoc xong mon hoc de duoc thi'
		ROLLBACK TRANSACTION
	END
END

--INSERT INTO KETQUATHI (MAHV, MAMH, LANTHI, NGTHI, DIEM, KQUA)
--VALUES 
        
--		('K1211', 'CSDL' ,1, '2006/20/05', 10.00, 'Dat');
GO
-- Trigger len GIANGDAY
CREATE TRIGGER trg_ins_ketqua_GD_22 ON GIANGDAY
FOR INSERT, UPDATE
AS
BEGIN 
	IF NOT EXISTS (SELECT * FROM INSERTED I, HOCVIEN HV, KETQUATHI KQ
	WHERE I.MALOP = HV.MALOP AND HV.MAHV = KQ.MAHV AND I.MAMH = KQ.MAMH AND I.DENNGAY < KQ.NGTHI)
	BEGIN
		PRINT 'Error: Ngay ket thuc lop phai som hon ngay thi mon hoc'
		ROLLBACK TRANSACTION
	END
END
GO


/* 23.	Khi phân công giảng dạy một môn học, phải xét đến thứ tự trước sau giữa các môn học 
(sau khi học xong những môn học phải học trước mới được học những môn liền sau). */
create TRIGGER trg_ins_thutuphancong_dkmh ON DIEUKIEN
FOR INSERT, UPDATE
AS 
	DECLARE @MAMH varchar(10), @MAMH_TRUOC varchar(10), @MAMH2 varchar(10)
	SELECT @MAMH = I.MAMH, @MAMH_TRUOC = I.MAMH_TRUOC, @MAMH2 = DK.MAMH  FROM INSERTED I, DIEUKIEN DK
	IF(@MAMH_TRUOC = @MAMH2)
		BEGIN
			Print 'Phan cong mon hoc hop ly'
			Rollback Transaction
		END
	Else
		PRINT 'Can phai day mon hoc truoc'
GO
create TRIGGER trg_ins_thutuphancong ON GIANGDAY
FOR INSERT, UPDATE
AS 
	DECLARE @DENNGAY1 SMALLDATETIME, @TUNGAY2 smalldatetime
	SELECT @DENNGAY1 = GD.DENNGAY, @TUNGAY2 = I.TUNGAY FROM INSERTED I, GIANGDAY GD, GIAOVIEN GV
	WHERE GV.MAGV = I.MAGV
	IF(@TUNGAY2 < @DENNGAY1)
	BEGIN
		Print 'Error: Phai hoan thanh mon hoc truoc'
		Rollback Transaction
	END
	ELSE
		PRINT 'Phan cong thoi gian hop ly'
GO
/*
INSERT INTO GIANGDAY (MALOP, MAMH, MAGV, HOCKY, NAM, TUNGAY, DENNGAY)
VALUES
('K11' ,'LTHDT' ,'GV12', 3 ,2006 ,'2006-10-02' ,'2006-05-12');
GO
*/


-- 24.	Giáo viên chỉ được phân công dạy những môn thuộc khoa giáo viên đó phụ trách.
Create Trigger trg_ins_phancong ON GIANGDAY
FOR INSERT, UPDATE
AS	
BEGIN
	IF NOT EXISTS (SELECT * FROM INSERTED I, MONHOC MH, GIAOVIEN GV
	WHERE I.MAMH = MH.MAMH AND I.MAGV = GV.MAGV AND MH.MAKHOA = GV.MAKHOA)
	BEGIN 
		PRINT 'Error: Giao vien chi day nhung mon duoc phu trach'
		Rollback Transaction
	END
END
GO
/*
INSERT INTO GIANGDAY(MALOP, MAMH, MAGV, HOCKY, NAM, TUNGAY, DENNGAY)
VALUES
('K13' ,'LTHDT' ,'GV01', 1 ,2006 ,'2006-01-02' ,'2006-05-12');
*/
/*
SELECT * FROM KHOA 
SELECT * FROM MONHOC 
SELECT * FROM DIEUKIEN
SELECT * FROM GIAOVIEN
SELECT * FROM LOP
SELECT * FROM HOCVIEN
SELECT * FROM GIANGDAY
SELECT * FROM KETQUATHI
GO
*/
